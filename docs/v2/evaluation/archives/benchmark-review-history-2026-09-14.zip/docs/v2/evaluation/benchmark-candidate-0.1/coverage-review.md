# 全快照覆盖确认入口

审阅对象：`reviewed-annotations-0.1`；corpus `novatech-pilot-0.1`；snapshot `t2001-novatech-pilot-01`（38 块）。
**后续 Human 决定（2026-09-11）：40/40 full-snapshot coverage APPROVED，无遗漏正证据。** Human 对完整覆盖确认请求回复「确认」，决定引用 H-BC01-Q001-Q040-COVERAGE-2026-09-11；范围为本页指定的已批准 40 题和冻结 38 块。记录见 [Human ledger](human-decisions.md)及 [标注汇总 0.2](reviewed-annotations-0.2.json)。下文说明保留原审阅问题与确认方式；不再要求重复确认。

## 本次已确认的事实

对具体题目的已批准问法，你是否实际核对了完整冻结快照，并确认没有遗漏正证据或需要纠正的等级？
这不是再生成一套标签。先前检查仍可作为你的审阅工作；如果确实已检查完整内容，可以统一确认，不要求重新逐题回复。但先前明确“覆盖暂不确认”的决定不能由助手自动升级。
全部等级是显式记录，因此没有用未列块自动补 0；契约要求的独立 Human coverage 决定仍须保留。

## 检查入口

| 题目范围 | 已批准问法与人工等级 | 全文 | coverage |
|---|---|---|---|
| Q001–Q004 | [最终矩阵](coverage-matrices.md#batch-1) · [逐项 Human 记录](round2-batch-01-reviewed.json) | [完整 38 块](evidence-inventory.md) | APPROVED |
| Q005–Q010 | [最终矩阵](coverage-matrices.md#batch-2) · [逐项 Human 记录](round2-batch-02-reviewed.json) | [完整 38 块](evidence-inventory.md) | APPROVED |
| Q011–Q020 | [最终矩阵](coverage-matrices.md#batch-3) · [逐项 Human 记录](round2-batch-03-reviewed.json) | [完整 38 块](evidence-inventory.md) | APPROVED |
| Q021–Q030 | [最终矩阵](coverage-matrices.md#batch-4) · [逐项 Human 记录](round2-batch-04-reviewed.json) | [完整 38 块](evidence-inventory.md) | APPROVED |
| Q031–Q040 | [最终矩阵](coverage-matrices.md#batch-5) · [逐项 Human 记录](round2-batch-05-reviewed.json) | [完整 38 块](evidence-inventory.md) | APPROVED |

矩阵使用 Human grade，尤其 Q002/E6 已是 0；原待审矩阵中的 1 仅为历史建议。七道改写题采用第一轮批准后的最终问法。

## 原确认方式（历史说明，本次已确认）

仅在你已实际完成检查时，可批量确认：“针对 reviewed-annotations-0.1、novatech-pilot-0.1 / t2001-novatech-pilot-01，我已核对 Q001–Q040 各自对应的完整 38 块，确认没有遗漏正证据，批准这 40 题的 full-snapshot coverage。”
如只检查了部分，列明具体题号；其余继续 PENDING。如发现遗漏或等级问题，提供 query_id、chunk_alias/UUID、建议修正，先保留 NEEDS_REVIEW，不把冲突掩盖为覆盖通过。
覆盖确认不包含 Dev/Test、family、最终去重、40+8 质量目标差额、语料最终复用或 dataset promotion，也不启动 T2003。

## 整理与核验结果

- 40 个唯一题号，每题 38 个唯一冻结 chunk_id，共 1,520 项 Human 等级，全部来源可追溯。
- 32 Answerable 都有 grade≥2 的人工证据；8 Unanswerable 都没有 grade≥2，均保留一个 Grade 1 邻近政策块。
- 对照最初候选，共 7 道问法改写、19 项等级调整；原始建议和人工决定均保留。
- 核验了五个待审包的 hash、五个已审包来源、冻结快照 hash、逐项 UUID/file/index、最终问法 hash、Human 等级与明确批准范围。
- 整理矩阵时未产生 Human coverage 决定；后续明确确认已记录在本页开头。无检索/指标运行，无模型或实时索引验证。
- [汇总的人工标注（非正式 Runner 输入）](reviewed-annotations-0.1.json) · [人工决定表](human-decisions.md)。
