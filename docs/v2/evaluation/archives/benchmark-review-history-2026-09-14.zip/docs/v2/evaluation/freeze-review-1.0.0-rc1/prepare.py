"""Prepare/check a freeze-review packet. No retrieval, model or metric execution."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
BASE = ROOT / 'docs/v2/evaluation'
VERSION = 'novatech-retrieval-benchmark-1.0.0-rc1'
SOURCES = {
    'annotations.json': BASE/'benchmark-candidate-0.1/reviewed-annotations-0.2.json',
    'initial-candidates.json': BASE/'benchmark-candidate-0.1/candidates.json',
    'annotation-decisions.md': BASE/'benchmark-candidate-0.1/human-decisions.md',
    'split.json': BASE/'fact-split-draft-0.1/reviewed-fact-split-0.1.json',
    'split-decision.md': BASE/'fact-split-draft-0.1/human-approval.md',
    'overlap-audit.json': BASE/'fact-split-draft-0.1/audit.json',
    'dedup.json': BASE/'semantic-dedup-review-0.1/reviewed-decisions-0.1.json',
    'dedup-decisions.md': BASE/'semantic-dedup-review-0.1/human-decisions.md',
    'size-corpus.json': BASE/'size-corpus-review-0.1/reviewed-decisions-0.1.json',
    'size-corpus-decision.md': BASE/'size-corpus-review-0.1/human-decisions.md',
    'size-corpus-proposal.json': BASE/'size-corpus-review-0.1/review.json',
    'snapshot.json': BASE/'pilot-snapshot-01/snapshot.json',
    'contract.md': BASE/'retrieval-evaluation-dataset-contract.md',
    'corpus-provenance.md': BASE/'pilot-corpus/README.md',
    'dataset-validator.py': ROOT/'backend/evaluation/dataset.py',
}
for name in ('employee_handbook.md','travel_policy.md','expense_policy.md','it_security_policy.md'):
    SOURCES['corpus/'+name] = BASE/'pilot-corpus'/name

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def human(ref, date='2026-09-11'):
    return {'status':'APPROVED','role':'Human project owner','date':date,'decision_ref':ref}

def derive():
    evidence = HERE/'evidence'
    a=read(evidence/'annotations.json'); s=read(evidence/'split.json')
    snapshot=read(evidence/'snapshot.json'); initial=read(evidence/'initial-candidates.json')
    dedup=read(evidence/'dedup.json'); scope=read(evidence/'size-corpus.json')
    assert s['human_family_split_review']=='APPROVED'
    assert len(dedup['groups'])==20 and all(g['human_decision']=='APPROVED_KEEP_ALL' for g in dedup['groups'])
    assert all(x['human_decision']=='APPROVED' for x in scope['decisions'])
    assert scope['formal_freeze']==scope['dataset_promotion']=='PENDING'
    assert a['source_snapshot_sha256']==s['source_snapshot_sha256']==sha((evidence/'snapshot.json').read_bytes())
    assert s['source_annotations']['sha256']==sha((evidence/'annotations.json').read_bytes())
    assert dedup['source_reviewed_split_sha256']==sha((evidence/'split.json').read_bytes())
    for key,name in [('contract','contract.md'),('snapshot','snapshot.json'),('annotations','annotations.json'),('split','split.json'),('dedup','dedup.json')]:
        assert scope['source_hashes'][key]==sha((evidence/name).read_bytes())
    assert scope['source_review_sha256']==sha((evidence/'size-corpus-proposal.json').read_bytes())
    for item in snapshot['sources']:
        assert sha((evidence/'corpus'/item['file_name']).read_bytes())==item['sha256']
    inventory={c['chunk_id']:c for c in initial['inventory']}
    frozen={c['chunk_id']:c for c in snapshot['chunks']}
    assert len(inventory)==len(frozen)==38 and set(inventory)==set(frozen)
    for cid,c in inventory.items():
        assert all(c[k]==frozen[cid][k] for k in ('content','file_name','file_id','chunk_index'))
        assert c['content_sha256']==sha(c['content'].encode('utf-8'))
    split={q['query_id']:q for q in s['queries']}
    assert set(split)=={f'BC01-Q{i:03}' for i in range(1,41)}
    queries=[]
    for q in a['queries']:
        qid=q['query_id']; assignment=split[qid]
        assert q['question_review_status']=='APPROVED'
        assert q['query_text']==assignment['query_text']
        assert q['query_text_sha256']==sha(q['query_text'].encode('utf-8'))
        assert q['human_answerable']==assignment['answerable']
        assert q['human_query_category']==assignment['category']
        coverage=q['human_coverage_review']; assert coverage['status']=='APPROVED'
        judgments=[]
        for j in q['judgments']:
            assert j['human_review_status']=='APPROVED'
            c=inventory[j['chunk_id']]
            assert all(j[k]==c[k] for k in ('file_name','file_id','chunk_index','chunk_alias'))
            assert type(j['human_grade']) is int and j['human_grade'] in range(4)
            judgments.append({k:j[k] for k in ('chunk_id','file_name','file_id','chunk_index','human_grade','suggested_grade')} | {
                'review':human(j['human_decision_ref']),
                'rationale':j['human_rationale']+' | Suggestion context: '+j['suggestion_rationale']})
        assert len(judgments)==38 and {j['chunk_id'] for j in judgments}==set(inventory)
        assert any(j['human_grade']>=2 for j in judgments)==q['human_answerable']
        queries.append({'query_id':qid,'query_text':q['query_text'],'query_text_sha256':q['query_text_sha256'],
            'query_category':q['human_query_category'],'answerable':q['human_answerable'],
            'corpus_version':a['corpus_version'],'snapshot_id':a['snapshot_id'],
            'split':assignment['draft_split'],'evidence_family_id':assignment['family_id'],
            'coverage_reviewed':q['coverage_reviewed'],'review_status':'APPROVED',
            'review':human(q['first_round_decision_ref']),
            'coverage_review':human(coverage['decision_ref'],coverage['date']) | {
                'full_snapshot_screened':coverage['full_snapshot_screened'],
                'no_positive_omissions':coverage['no_positive_omissions']},
            'judgments':judgments})
    assert len(queries)==40
    families={}
    for q in queries:
        assert families.setdefault(q['evidence_family_id'],q['split'])==q['split']
    assert len(families)==20
    return {'schema_version':'1','contract_version':'0.3','purpose':'benchmark',
        'dataset_version':VERSION,'corpus_version':a['corpus_version'],
        'snapshot_id':a['snapshot_id'],'collection':a['snapshot_id'],
        'artifact_status':'FREEZE_REVIEW_ONLY','formal_freeze':'PENDING','dataset_promotion':'PENDING',
        'benchmark_authorized':False,
        'review':{'status':'PENDING','role':'Human project owner','date':'2026-09-14',
                  'decision_ref':'PENDING_FINAL_HUMAN_APPROVAL'},
        'provenance':{
            'source':'DX-RAG original AI-assisted fictional NovaTech Chinese policy corpus; evidence/corpus-provenance.md and evidence/snapshot.json.',
            'distribution_basis':'Original project material; fictional company, no real employee data; source provenance retained.',
            'annotation_method':'LLM candidate suggestions followed by Human project owner wording/category/answerability, all 1520 grades, full coverage, facts/splits, 20 dedup groups and SC01/SC02 decisions. Single reviewer; no inter-annotator agreement claim. Frozen promotion is still pending.',
            'git_context':'See manifest.json git_context and tool hashes; files are working-tree artifacts, not claimed present in HEAD. V1 reference tag v1.0.0.',
            'limitations':' | '.join(scope['limitations'])+' | No live model/index/store readiness check; UUIDs tied to original snapshot. Reingestion needs identity reconciliation/review. V1 metadata/page provenance and tied-score repeatability limitations remain; no retrieval outputs or measured metrics in this package.',
            'ingestion_config':json.dumps(snapshot['runtime_confirmed'],ensure_ascii=False)+'; historical V1 ingestion evidence, not a new ingestion. Full configuration in evidence/snapshot.json.',
            'model_version':json.dumps(snapshot['embedding_runtime'],ensure_ascii=False)+'; historical models/bge-small-zh-v1.5 with model_files_sha256 retained in evidence/snapshot.json; current model and vectors not verified.',
            'approval_evidence':['evidence/annotation-decisions.md','evidence/split-decision.md','evidence/dedup-decisions.md','evidence/size-corpus-decision.md'],
        },
        'snapshot':{'corpus_version':a['corpus_version'],'snapshot_id':a['snapshot_id'],
            'chunks':[{k:c[k] for k in ('chunk_id','file_id','file_name','chunk_index','content_sha256')} for c in initial['inventory']]},
        'queries':queries}

def validate():
    manifest=read(HERE/'manifest.json')
    for name,digest in manifest['files_sha256'].items():
        assert sha((HERE/name).read_bytes())==digest,('packet changed',name)
    for name,info in manifest['upstream_sources'].items():
        assert sha((ROOT/info['repository_path']).read_bytes())==info['sha256'],('upstream drift',name)
    data=read(HERE/'dataset.json'); assert data==derive(),'derived dataset drift'
    spec=importlib.util.spec_from_file_location('frozen_dataset_validator',HERE/'evidence/dataset-validator.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for q in data['queries']:
        module.review(q['review'],q['query_id'],False)
        module.review(q['coverage_review'],q['query_id']+' coverage',False)
        assert q['coverage_reviewed'] is True
        assert q['query_category'] in module.CATEGORIES
        for flag in ('full_snapshot_screened','no_positive_omissions'):
            assert q['coverage_review'][flag] is True
        for j in q['judgments']:
            module.review(j['review'],q['query_id']+' judgment',False)
            assert j['human_grade']==j['suggested_grade'] or bool(j['rationale'])
    try:
        module.validate_dataset(data)
    except ValueError as exc:
        assert str(exc)=='dataset promotion: review not APPROVED',str(exc)
    else:
        raise AssertionError('Unapproved dataset unexpectedly passed the execution gate')
    counts={side:dict(Counter(q['query_category'] for q in data['queries'] if q['answerable'] and q['split']==side)) for side in ('Dev','Test')}
    grades=dict(sorted(Counter(j['human_grade'] for q in data['queries'] for j in q['judgments']).items()))
    assert grades=={0:1446,1:8,2:21,3:45}
    return {'content_checks':'PASS','packet_and_upstream_hashes':'PASS','query_count':40,
        'judgment_count':1520,'grade_counts':grades,'answerable_categories':counts,
        'execution_gate':'EXPECTED_BLOCK: dataset promotion: review not APPROVED',
        'formal_freeze':'PENDING','dataset_promotion':'PENDING','benchmark_executed':False,
        'live_readiness':'NOT_CHECKED'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');args=parser.parse_args()
    if not args.check:
        assert not (HERE/'manifest.json').exists(),'Existing review packet: use --check; do not overwrite reviewed bytes'
        upstream={}
        for name,source in SOURCES.items():
            target=HERE/'evidence'/name;target.parent.mkdir(parents=True,exist_ok=True)
            content=source.read_bytes();target.write_bytes(content)
            upstream[name]={'repository_path':source.relative_to(ROOT).as_posix(),'sha256':sha(content)}
        data=derive();(HERE/'dataset.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT,text=True,encoding='utf-8').strip()
        manifest={'packet_version':VERSION,'status':'FREEZE_REVIEW_ONLY','created_date':'2026-09-14',
            'dataset_sha256':sha((HERE/'dataset.json').read_bytes()),'upstream_sources':upstream,
            'git_context':{'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),
                'v1_tag_commit':git('rev-parse','v1.0.0^{commit}'),'working_tree_status':git('status','--short'),
                'product_diff_vs_v1':git('diff','v1.0.0','--stat','--','backend/app','frontend')},
            'tool_hashes':{x.relative_to(ROOT).as_posix():sha(x.read_bytes()) for x in sorted((ROOT/'backend/evaluation').glob('*.py'))},
            'files_sha256':{x.relative_to(HERE).as_posix():sha(x.read_bytes()) for x in sorted(HERE.rglob('*')) if x.is_file() and '__pycache__' not in x.parts},
            'hash_scope':'All packet files present before manifest, including README/prepare/dataset/evidence. manifest and subsequently generated verification.json are excluded to avoid self-reference.',
            'formal_freeze':'PENDING','dataset_promotion':'PENDING','benchmark_authorized':False}
        (HERE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report=validate()
    if not args.check:
        (HERE/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    else:
        assert read(HERE/'verification.json')==json.loads(json.dumps(report))
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':
    main()
