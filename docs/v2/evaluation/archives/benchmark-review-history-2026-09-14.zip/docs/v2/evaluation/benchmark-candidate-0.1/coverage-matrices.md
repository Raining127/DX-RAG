# 人工最终等级矩阵 — Coverage 已确认

以下使用已批准的最终问法和 Human grade；不是初始建议。snapshot：`t2001-novatech-pilot-01`，38 块。

<a id="batch-1"></a>
## Q001–Q004

[覆盖确认说明](coverage-review.md)

- **BC01-Q001**：不涉及客户现场排班时，正常工作日允许几点到岗？午休多长，下班时间怎样确定？
- **BC01-Q002**：新员工入职首周由谁说明岗位目标、安排带教和培训？试用期间多久反馈一次？
- **BC01-Q003**：非紧急情况下，计划连续请假三天和四天，通常各需提前多少个工作日申请？
- **BC01-Q004**：年度体检由谁统一预约？自己加做检查前需要确认什么？

| 块 / 全文 | 主题 | Q001 | Q002 | Q003 | Q004 |
|---|---|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 3 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 3 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 3 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 3 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 |

Human 等级已批准；本组 full-snapshot coverage 已于 2026-09-11 按 H-BC01-Q001-Q040-COVERAGE-2026-09-11 批准，无遗漏正证据。

<a id="batch-2"></a>
## Q005–Q010

[覆盖确认说明](coverage-review.md)

- **BC01-Q005**：财务审核通过的员工垫付款通常哪天集中支付，返还到哪个账户？
- **BC01-Q006**：境内消费的电子发票要交什么文件？只有付款截图可以吗，发票信息错了怎么办？
- **BC01-Q007**：境内普通商务出差一般选什么高铁席位或飞机舱位？没有普通席位而必须升级时谁批准？
- **BC01-Q008**：哪些公司系统必须启用 MFA？更换手机后怎样恢复认证访问？
- **BC01-Q009**：我还在试用期，想固定每周在家干两天，可以按常规远程办公安排申请吗？
- **BC01-Q010**：IT 催我装关键更新，但这两天要在客户现场工作，赶不及怎么办？

| 块 / 全文 | 主题 | Q005 | Q006 | Q007 | Q008 | Q009 | Q010 |
|---|---|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 3 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 3 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 3 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 3 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 2 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 0 | 3 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 3 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 0 |

Human 等级已批准；本组 full-snapshot coverage 已于 2026-09-11 按 H-BC01-Q001-Q040-COVERAGE-2026-09-11 批准，无遗漏正证据。

<a id="batch-3"></a>
## Q011–Q020

[覆盖确认说明](coverage-review.md)

- **BC01-Q011**：一张普通报销单里带着银行账号和客户信息，能只看它叫“报销单”就当作普通公开文件吗？
- **BC01-Q012**：电脑可能中了恶意软件，我是不是该在这台电脑上赶紧反复改密码、重装系统，把痕迹清掉？
- **BC01-Q013**：跑完一趟客户行程，商家还没补开发票，我能一直等票齐了再报吗？
- **BC01-Q014**：这笔钱已经刷公司卡付了，我还要报费用吗，能再打到我个人账户吗？
- **BC01-Q015**：客户突然出故障，需要我立即进行境内普通商务出差，来不及提前申请，先要留什么确认、之后何时补单？
- **BC01-Q016**：客户临时改了安排，原来的车票和酒店不用了，退改损失和拿回的退款该怎样报？
- **BC01-Q017**：去上海普通商务出差，酒店实际每晚 420 元，我能按 500 元上限领满吗？
- **BC01-Q018**：获批外部培训的主办方已经包住宿了，我还能按每晚 350 元向公司领一份住宿补贴吗？
- **BC01-Q019**：境内普通出差一天，客户提供了午餐和晚餐，我还能领全天 80 元餐补吗？
- **BC01-Q020**：报销已经到账，后来商家又退了一部分钱，这笔退款可以自己留下吗？

| 块 / 全文 | 主题 | Q011 | Q012 | Q013 | Q014 | Q015 | Q016 | Q017 | Q018 | Q019 | Q020 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 2 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 0 | 2 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 2 | 0 | 0 | 2 | 0 | 2 | 0 | 2 | 0 | 3 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Human 等级已批准；本组 full-snapshot coverage 已于 2026-09-11 按 H-BC01-Q001-Q040-COVERAGE-2026-09-11 批准，无遗漏正证据。

<a id="batch-4"></a>
## Q021–Q030

[覆盖确认说明](coverage-review.md)

- **BC01-Q021**：在家用的是我自己设密码的 Wi-Fi，访问公司内部系统就可以不连 VPN 吗？
- **BC01-Q022**：邮件显示是领导，让我马上修改收款账户，还留了核实电话，照着邮件里的号码打过去就能确认靠谱吗？
- **BC01-Q023**：客户现场没网，我能把工作文件拷到自己的 U 盘交付吗？如果确实需要离线介质该怎么做？
- **BC01-Q024**：我人在公司受管办公网络，同事让我借他的账号临时查资料，这样可以省去权限申请吗？
- **BC01-Q025**：已转正且岗位适合远程办公，我想下周固定在家工作两天：何时申请、谁批准，获批后用什么设备、怎样接入内部系统？
- **BC01-Q026**：离职前工作文件、电脑和认证设备分别怎么交接，谁办理账号停用，旧合作链接的权限又由谁撤销？
- **BC01-Q027**：连续病假三天，返岗后记录和医疗证明要怎样提交？人力资源部接收这些材料后，应如何分类并控制内部访问权限？
- **BC01-Q028**：参加收费的外部课程，从报名到预算应找谁确认？参训行程结束后多久提交费用？
- **BC01-Q029**：去境外拜访客户，要提前多久申请、经谁批准？当地拿不到境内发票时，用什么凭证说明外币费用？
- **BC01-Q030**：我在境内普通出差期间用公司费用请客户吃饭，招待应事先经谁批准、通常每人上限多少，参加这餐的员工个人餐补如何处理？

| 块 / 全文 | 主题 | Q021 | Q022 | Q023 | Q024 | Q025 | Q026 | Q027 | Q028 | Q029 | Q030 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 3 | 0 | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 2 | 0 | 0 | 3 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 | 0 | 3 | 3 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 2 | 3 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 |

Human 等级已批准；本组 full-snapshot coverage 已于 2026-09-11 按 H-BC01-Q001-Q040-COVERAGE-2026-09-11 批准，无遗漏正证据。

<a id="batch-5"></a>
## Q031–Q040

[覆盖确认说明](coverage-review.md)

- **BC01-Q031**：同一趟上海行程先培训后拜访客户，均无住宿超限特别批准，两段住宿各适用多少报销上限、预订时怎样区分用途；同一天两种活动都有，餐费能按两套规则各领一次吗？
- **BC01-Q032**：境内普通商务出差申请已经批了，但展会酒店都超住宿限额，预计总预算也要增加，订房前应补哪些批准和证明？
- **BC01-Q033**：按公司规定，我这次获批用私家车出差，每公里具体报销多少元？
- **BC01-Q034**：我要让商家给公司开票，公司发票抬头的完整名称和纳税人识别号分别是什么？
- **BC01-Q035**：我的报销已通过财务审核，公司承诺最迟几个工作日一定到账？
- **BC01-Q036**：这次去新加坡见客户，公司已经批下来的专项预算里，每晚酒店上限是多少新加坡元？
- **BC01-Q037**：我今年获批的带薪年假额度具体是多少天？
- **BC01-Q038**：我签的这份劳动合同里，试用期具体约定了几个月？
- **BC01-Q039**：公司今年年度体检套餐给每位员工安排的预算具体是多少元？
- **BC01-Q040**：我要装公司 VPN，公司批准使用的客户端品牌和官方下载地址是什么？

| 块 / 全文 | 主题 | Q031 | Q032 | Q033 | Q034 | Q035 | Q036 | Q037 | Q038 | Q039 | Q040 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 2 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |

Human 等级已批准；本组 full-snapshot coverage 已于 2026-09-11 按 H-BC01-Q001-Q040-COVERAGE-2026-09-11 批准，无遗漏正证据。
