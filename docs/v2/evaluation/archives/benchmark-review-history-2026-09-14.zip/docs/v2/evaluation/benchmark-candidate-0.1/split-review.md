# Evidence-family 与 Dev/Test 待审划分

这是候选检查结果，不是 Human-approved split，也不是没有语义泄漏的证明。

先将所有共享 suggested grade≥2 chunk 的题连接，再对 Multi-chunk 做传递合并；无答案题归入其所问政策的家族。
这种方法比契约的“同一核心事实”更保守：同一 chunk 可含不同事实，因此可能过度合并。不得通过降低相关等级来拆组。
Human 可以审阅并细化核心事实，但必须记录事实边界与理由，检查跨 split 的实质重叠；结构检查不能代替该判断。

| 家族 | 建议 split | A/U 数 | 题目 | 实质证据 / 缺失事实归属 |
|---|---|---|---|---|
| BC01-F01 | Dev | 1/0 | BC01-Q001 | E2 |
| BC01-F02 | Test | 1/1 | BC01-Q002, BC01-Q038 | E3 |
| BC01-F03 | Dev | 26/4 | BC01-Q003, BC01-Q006, BC01-Q008, BC01-Q009, BC01-Q010, BC01-Q011, BC01-Q012, BC01-Q013, BC01-Q014, BC01-Q015, BC01-Q016, BC01-Q017, BC01-Q018, BC01-Q019, BC01-Q020, BC01-Q021, BC01-Q022, BC01-Q024, BC01-Q025, BC01-Q026, BC01-Q027, BC01-Q028, BC01-Q029, BC01-Q030, BC01-Q031, BC01-Q032, BC01-Q034, BC01-Q036, BC01-Q037, BC01-Q040 | E4, E5, E6, E8, E9, I1, I2, I3, I4, I5, I7, I8, I9, T1, T2, T4, T5, T6, T7, T8, X1, X2, X4, X5, X6, X7, X8 |
| BC01-F04 | Test | 1/1 | BC01-Q004, BC01-Q039 | E7 |
| BC01-F05 | Test | 1/1 | BC01-Q005, BC01-Q035 | X3 |
| BC01-F06 | Test | 1/1 | BC01-Q007, BC01-Q033 | T3 |
| BC01-F07 | Test | 1/0 | BC01-Q023 | I6 |

## 与质量目标的差额

| split | Answerable | Unanswerable | Direct Fact / Paraphrase / Distractor / Multi-chunk（仅 Answerable） |
|---|---:|---:|---|
| Dev | 27 | 4 | 4 / 8 / 7 / 8 |
| Test | 5 | 4 | 4 / 0 / 1 / 0 |

总计 32 Answerable（四类各 8）+8 Unanswerable；契约目标为 40+8，少 8 道 Answerable，四类各少 2。
每个 split 的目标是 20+4、Answerable 每类 5；当前 Dev 为 27+4，Test 为 5+4。Test 没有可回答的 Paraphrase/Multi-chunk，不能支持这些类别的 held-out 比较。

## 核心诊断与处理选择

- F03 含 30 题：Q011 用费用材料的数据保护连接 X8 与 I4/I5；Q026/Q027 连接安全、离职与假期；Q028/Q031/Q032 连接培训、差旅和报销。这是语料关联密集的诊断，不是 30 个独立事实样本。
- Pilot 相关的 F01/F03 暂放 Dev；历史 Pilot 已参与契约及工具设计。Test 只是未来调参的拟议隔离，不能声称对标注者/本次助手完全未见。
- Q025 与 Pilot-CQ-006 接近，应优先决定删去扩展题或替换，不凭题数宣称新增独立覆盖。
- 建议先完成问题质量审阅，再按核心事实细化大组并审核泄漏；如果仍缺独立 Test 内容，另行扩充原创语料、生成新快照，再补题和重新映射标注。
- 当前快照所有实体是虚构组织；问法/判断由同一 LLM 辅助产生，且 primary reviewer 为单人。未评估真实企业用户分布、长文档、OCR 和跨语言泛化。
- 八道 Unanswerable 都是有相邻政策但缺具体数值/产品资料的弱相关边界，不代表全部不可回答场景，更不能证明生成层会正确拒答。
- 现阶段不要冻结此 split。若最终接受低于目标的规模或类别缺口，须由 Human 明确批准并保留这些局限。
