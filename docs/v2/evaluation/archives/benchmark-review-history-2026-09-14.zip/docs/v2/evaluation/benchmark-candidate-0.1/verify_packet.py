"""Read-only checks for candidate packet 0.1; no retrieval or model initialization."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def check(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    raw = (HERE / 'candidates.json').read_bytes()
    data = json.loads(raw)
    source = (HERE / data['source_snapshot_path']).resolve()
    check(hashlib.sha256(source.read_bytes()).hexdigest() == data['source_snapshot_sha256'], 'Snapshot file changed')
    snapshot = json.loads(source.read_text(encoding='utf-8'))
    for item in snapshot['sources']:
        check(hashlib.sha256((ROOT / item['repository_path']).read_bytes()).hexdigest()==item['sha256'], 'Corpus source changed')
    source_chunks = {c['chunk_id']: c for c in snapshot['chunks']}
    inventory = {c['chunk_id']: c for c in data['inventory']}
    aliases = {c['chunk_alias']: c for c in data['inventory']}
    check(len(inventory)==len(aliases)==len(data['inventory'])==38, 'Inventory uniqueness/count')
    check(set(inventory)==set(source_chunks), 'Snapshot IDs differ')
    for cid, c in inventory.items():
        original = source_chunks[cid]
        for key in ('file_id', 'file_name', 'chunk_index', 'content'):
            check(c[key]==original[key], 'Snapshot field mismatch: '+key)
        check(hashlib.sha256(c['content'].encode('utf-8')).hexdigest()==c['content_sha256'], 'Text hash mismatch')
    qs = data['queries']
    check(len(qs)==40 and len({q['query_id'] for q in qs})==40, 'Query uniqueness/count')
    check(len({q['query_text'] for q in qs})==40, 'Duplicate wording')
    check(sum(q['suggested_answerable'] for q in qs)==32, 'Answerable count')
    check(Counter(q['suggested_query_category'] for q in qs if q['suggested_answerable']) ==
          Counter({'Direct Fact':8,'Paraphrase':8,'Distractor':8,'Multi-chunk':8}), 'Answerable categories')
    families = {f['evidence_family_id']: f for f in data['families']}
    chunk_splits = {}
    count = 0
    for q in qs:
        check(q['corpus_version']==data['corpus_version'] and q['snapshot_id']==snapshot['snapshot_id'], 'Query binding')
        check(q['review_status']=='PENDING' and q['coverage_reviewed'] is False, 'Premature Human approval')
        check(all(q[k] is None for k in ('human_query_text','human_query_category','human_answerable','human_split')), 'Human fields populated')
        check(all(v=='PENDING' if k.endswith('_status') else v is None for k,v in q['human_review'].items()), 'Human metadata populated')
        js = q['judgments']
        check(len(js)==38 and len({j['chunk_id'] for j in js})==38, 'Incomplete/duplicate screening')
        check({j['chunk_id'] for j in js}==set(inventory), 'Screening IDs differ')
        for j in js:
            c = inventory[j['chunk_id']]
            for key in ('chunk_alias','file_id','file_name','chunk_index'):
                check(j[key]==c[key], 'Judgment identity mismatch')
            check(type(j['suggested_grade']) is int and j['suggested_grade'] in range(4), 'Invalid suggested grade')
            check(bool(j['suggestion_rationale'].strip()), 'Missing rationale')
            check(j['human_grade'] is None and j['human_review_status']=='PENDING' and j['human_rationale'] is None and j['human_decision_ref'] is None, 'Judgment prematurely approved')
        substantive = {j['chunk_alias'] for j in js if j['suggested_grade']>=2}
        check(bool(substantive)==q['suggested_answerable'], 'Answerability/suggestion conflict')
        if q['suggested_query_category']=='Multi-chunk':
            check(len({j['chunk_id'] for j in js if j['suggested_grade']==3})>=2, 'Missing multi-chunk core suggestions')
        check(substantive.issubset(q['family_basis_aliases']), 'Family omits substantive evidence')
        f = families[q['evidence_family_id']]
        check(q['query_id'] in f['query_ids'] and q['suggested_split']==f['suggested_split'], 'Family assignment mismatch')
        for alias in q['family_basis_aliases']:
            check(alias in aliases, 'Unknown family policy anchor')
            chunk_splits.setdefault(alias,set()).add(q['suggested_split'])
        check(q['full_snapshot_screening']['screened_chunk_count']==38, 'Screening metadata mismatch')
        count += len(js)
    check(all(len(splits)==1 for splits in chunk_splits.values()), 'Cross-split shared substantive evidence')
    check(len(families)==7, 'Family count')
    check(sorted(i for f in families.values() for i in f['query_ids'])==sorted(q['query_id'] for q in qs), 'Family member partition mismatch')
    for f in families.values():
        check(f['human_split'] is None and f['human_review_status']=='PENDING', 'Family prematurely approved')
        actual = set(a for q in qs if q['query_id'] in f['query_ids'] for a in q['family_basis_aliases'])
        check(actual==set(f['policy_chunk_aliases']), 'Family anchors mismatch')
    check(data['review']['status']=='PENDING' and data['benchmark_ready'] is False and data['final_dataset_version'] is None, 'Promotion guard')
    split_counts = {}
    for split in ('Dev','Test'):
        subset = [q for q in qs if q['suggested_split']==split]
        split_counts[split] = [sum(q['suggested_answerable'] for q in subset), sum(not q['suggested_answerable'] for q in subset)]
    check(split_counts=={'Dev':[27,4],'Test':[5,4]}, 'Split diagnostics mismatch')
    from render_review import render
    for name, content in render(data).items():
        check((HERE/name).read_text(encoding='utf-8')==content.rstrip()+'\n', 'Stale view: '+name)
    # Only the pure dataset validator is imported. Draft is intentionally not runner schema 1.
    sys.path.insert(0, str(ROOT / 'backend'))
    from evaluation.dataset import validate_dataset
    try:
        validate_dataset(data)
    except ValueError as exc:
        runner_rejection = str(exc)
    else:
        raise ValueError('Candidate unexpectedly accepted as a benchmark')
    print(json.dumps(dict(status='PASS_CANDIDATE_STRUCTURE_ONLY', source_files=4, snapshot_chunks=38,
        queries=len(qs), suggestion_rows=count, human_approved_queries=0, human_approved_grades=0,
        families=len(families), proposed_splits=split_counts,
        candidate_sha256=hashlib.sha256(raw).hexdigest(), runner_rejection=runner_rejection,
        semantic_leakage_review='PENDING', human_coverage='PENDING', live_index_model='NOT_CHECKED'), indent=2))


if __name__=='__main__':
    main()
