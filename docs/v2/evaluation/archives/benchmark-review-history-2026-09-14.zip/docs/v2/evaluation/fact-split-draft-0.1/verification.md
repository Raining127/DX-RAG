# 草案结构核验

执行日期：2026-09-14；执行器为本目录 build_draft.py（Python 标准库）。这是本地文件核验，不调用 Runner、模型或检索。

复现：在项目根目录执行 `python docs/v2/evaluation/fact-split-draft-0.1/build_draft.py --check`。

- PASS：来源 annotations、snapshot、inventory、Pilot 文件 SHA-256 绑定；快照与已审标注记录一致。
- PASS：40 题唯一归属；每题 38 项已批准等级，coverage 已通过；所有人工正证据均有事实归因。
- PASS：事实引用均逐字来自指定冻结块；每条归因的 chunk 与事实来源一致。
- PASS：核心/前提与其他题核心/补充相交时合并；多事实题未拆分；U 关联与 grade 1 锚点一致。
- PASS：family 不跨侧；Pilot 已知核心事实相交题全部在 Dev；两侧各 16A+4U。
- PASS：补充事实跨侧与人工正证据块跨侧显式输出；空白规范化同文问题为 0。
- PASS：生成结果可用 --check 逐文件复核，事实/划分/晋升始终保持待审，benchmark_ready=false。

该核验不证明事实划界正确、语义完全去重或零泄漏。原人工标注文件只读；所有新内容均为派生草案。
