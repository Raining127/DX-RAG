# Candidate 0.1 核验记录

执行日期：2026-09-11。环境：Windows PowerShell / Python 3.14.6。工作分支 `v2/evaluation`，开始 HEAD `fe23d3846c276a7c127c29bc0ea3456b89ebbb89`。T2002 既有未提交内容保持；本包同样为工作区产物，不声称已存在于 HEAD，不执行 commit/push。

候选 JSON SHA-256：`ffff809843a84bfe6412321a6597d0f15301724db0c0866e32683695a4a08428`。

| 检查 | 实际结果 | 证据边界 |
|---|---|---|
| 4 份源文件 SHA-256 对照历史 snapshot | PASS | 只验证文本文件，没有重新入库 |
| 38 个 chunk_id、file_id、文件名、chunk_index、全文及 UTF-8 SHA-256 | PASS | 对照冻结 snapshot.json，不是实时 Chroma 回读或向量验证 |
| 40 个唯一题号和不重复问法 | PASS | 文本不重复不等于语义独立；Q025 与 Pilot 的接近程度另行披露 |
| 32 Answerable、四类各 8；8 Unanswerable | PASS | 全部为 LLM 分类建议，不是 Human 认可的分布 |
| 全部 40×38=1,520 行矩阵、等级范围及映射 | PASS | 全快照显式建议，不产生 implicit Human Grade 0 |
| Human query/grade/split/provenance 字段 | 0 个批准；全部 PENDING / null | 不虚构审阅身份、日期或决定 |
| 拟议 family 不跨 split，shared substantive chunk 不跨 split | PASS（结构） | 7 个保守家族；其中 F03 30 题。语义分组、过度合并和真实泄漏仍须 Human 审查 |
| Dev/Test 分布 | Dev 27A+4U；Test 5A+4U | 偏离每组 20A+4U 的目标；Test 缺可回答 Paraphrase/Multi-chunk，未验收 |
| 派生 Markdown 与 JSON 一致 | PASS | `render_review.py --check` 检查 6 个派生文件；不改 Human ledger |
| 现有官方 validator 接收候选文件 | 按预期拒收：`dataset: missing/invalid dataset_version` | 仅调用纯输入 validator，确认候选格式隔离；没有运行 Runner/检索或评估，也不是正式数据所有边界测试 |

可从仓库根目录重复执行：

```powershell
python docs/v2/evaluation/benchmark-candidate-0.1/verify_packet.py
python docs/v2/evaluation/benchmark-candidate-0.1/render_review.py --check
```

人工等级合理性、全快照 Human coverage、题型质量、语义去重、核心事实家族、代表性和最终 promotion 均未通过机器核验而自动升级。尚未检查本机实时索引/模型可用性，没有检索结果、Recall/MRR/nDCG、latency/cost 或质量提升结论。本次候选准备不启动 T2003，也不改变 Phase 20 Gate 状态。
