# 第二轮批次 3：Q011–Q020 证据等级与完整覆盖

版本：`R2-B03-0.1`；绑定 `novatech-pilot-0.1` / `t2001-novatech-pilot-01`（38 chunks）。
本批全部等级为待审建议，Human grade=null，coverage_reviewed=false；使用 [Human ledger](human-decisions.md) 已批准的问法，含 Q015 改写。
以下四处等级修订是新的 LLM 建议。其他题目的人工决定不自动批准本批。Q011/I5 仍建议 2，理由补充了受控链接和禁止公开访问的具体依据。

## 已批准的问题

- **BC01-Q011**：一张普通报销单里带着银行账号和客户信息，能只看它叫“报销单”就当作普通公开文件吗？
- **BC01-Q012**：电脑可能中了恶意软件，我是不是该在这台电脑上赶紧反复改密码、重装系统，把痕迹清掉？
- **BC01-Q013**：跑完一趟客户行程，商家还没补开发票，我能一直等票齐了再报吗？
- **BC01-Q014**：这笔钱已经刷公司卡付了，我还要报费用吗，能再打到我个人账户吗？
- **BC01-Q015**：客户突然出故障，需要我立即进行境内普通商务出差，来不及提前申请，先要留什么确认、之后何时补单？
- **BC01-Q016**：客户临时改了安排，原来的车票和酒店不用了，退改损失和拿回的退款该怎样报？
- **BC01-Q017**：去上海普通商务出差，酒店实际每晚 420 元，我能按 500 元上限领满吗？
- **BC01-Q018**：获批外部培训的主办方已经包住宿了，我还能按每晚 350 元向公司领一份住宿补贴吗？
- **BC01-Q019**：境内普通出差一天，客户提供了午餐和晚餐，我还能领全天 80 元餐补吗？
- **BC01-Q020**：报销已经到账，后来商家又退了一部分钱，这笔退款可以自己留下吗？

## 建议非零证据

| 问题 | Grade 3 核心证据 | Grade 2 实质相关证据 |
|---|---|---|
| BC01-Q011 | [I4](evidence-inventory.md#i4) | [X8](evidence-inventory.md#x8)、[I5](evidence-inventory.md#i5) |
| BC01-Q012 | [I8](evidence-inventory.md#i8) | [E9](evidence-inventory.md#e9) |
| BC01-Q013 | [X1](evidence-inventory.md#x1) | 无 |
| BC01-Q014 | [X4](evidence-inventory.md#x4) | [X8](evidence-inventory.md#x8) |
| BC01-Q015 | [T2](evidence-inventory.md#t2) | 无 |
| BC01-Q016 | [T7](evidence-inventory.md#t7) | [X4](evidence-inventory.md#x4)、[X8](evidence-inventory.md#x8) |
| BC01-Q017 | [T4](evidence-inventory.md#t4) | [X5](evidence-inventory.md#x5) |
| BC01-Q018 | [X7](evidence-inventory.md#x7) | [X8](evidence-inventory.md#x8) |
| BC01-Q019 | [T6](evidence-inventory.md#t6) | [X5](evidence-inventory.md#x5) |
| BC01-Q020 | [X8](evidence-inventory.md#x8) | [X4](evidence-inventory.md#x4) |

## 四处等级修订（待审）

| 问题 / 块 | 原建议 → 新建议 | 理由 |
|---|---|---|
| BC01-Q012 / [I3](evidence-inventory.md#i3) | 1 → 0 | 本块提供设备日常保护、更新和故障报告要求，没有回答疑似感染后是否改密码、重装或删除线索。 |
| BC01-Q013 / [E8](evidence-inventory.md#e8) | 1 → 0 | 仅要求返程按费用制度结算，没有提交期限或缺票时的登记安排。 |
| BC01-Q013 / [X2](evidence-inventory.md#x2) | 2 → 0 | 只规定有效票据、错票更正及遗失补开，不回答等商家补票时能否延期提交及如何登记。 |
| BC01-Q020 / [T7](evidence-inventory.md#t7) | 1 → 0 | 针对差旅行程退款在结算时冲减，未覆盖本题未限定费用类型且报销完成后才收到退款的处理；后到账规则由 X8 明确给出。 |

## 全快照矩阵：38 × 10 = 380 项

所有数字均为显式建议；每行链接完整正文。本批未建议 Grade 1，这不是取消该等级，也不改变冻结 rubric。

| 块 / 全文 | 主题 | Q011 | Q012 | Q013 | Q014 | Q015 | Q016 | Q017 | Q018 | Q019 | Q020 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 2 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 0 | 2 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 2 | 0 | 0 | 2 | 0 | 2 | 0 | 2 | 0 | 3 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

## 如何确认

核对后可批准“Q011–Q020，R2-B03-0.1 全部 380 项等级，包括四处调整”，并列例外。可以只批准指定 query/chunk，其余继续待审。
覆盖是独立决定，必须实际检查每题完整 38 块后才确认无遗漏正证据。等级通过不自动批准覆盖、family/split 或 dataset promotion。
机器可读及逐项理由：[round2-batch-03.json](round2-batch-03.json)。原建议与新建议均保留。
