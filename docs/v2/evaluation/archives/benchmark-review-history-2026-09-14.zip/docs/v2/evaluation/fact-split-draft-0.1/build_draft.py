"""Build/check a local review draft; no retrieval, model, or benchmark calls."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'benchmark-candidate-0.1'
ANNOTATIONS = SOURCE / 'reviewed-annotations-0.2.json'
INVENTORY = SOURCE / 'candidates.json'
PILOT = HERE.parent / 'pilot-snapshot-01-annotation-packet-draft.md'
SNAPSHOT = HERE.parent / 'pilot-snapshot-01/snapshot.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

# A fact is a policy obligation/decision, not every rule in the containing chunk.
# Select literal source sentences by unique fragments. Full sentences retain context.
FACTS = {
 'F01': ('正常工作日到岗、午休、下班', {'E2':['员工可在上午九点至十点']}),
 'F02': ('入职首周支持与试用期每月反馈', {'E3':['入职首周','试用期间每月']}),
 'F03': ('计划请假三天以内/超过三天的提前申请期限', {'E4':['通常连续请假三天以内']}),
 'F04': ('年度体检预约与加项承担范围确认', {'E7':['健康检查由人力资源部统一预约']}),
 'F05': ('报销每周三批量付款与本人登记账户', {'X3':['财务审核通过后','员工垫付返还']}),
 'F06': ('境内发票原始文件、信息正确与更正', {'X2':['境内采购和消费','电子发票直接提交','同时提供订单','发票信息错误']}),
 'F07': ('境内高铁二等座/经济舱与升级预先批准', {'T3':['境内出行优先','无普通席位']}),
 'F08': ('公司邮箱、VPN、远程访问的 MFA 要求', {'I1':['公司邮箱、VPN'],'I2':['通过公共或不可信网络']}),
 'F09': ('更换认证设备后的身份核验恢复', {'I1':['手机更换或认证设备遗失']}),
 'F10': ('转正且岗位合适才可申请每周最多两天远程', {'E5':['完成试用期且岗位适合']}),
 'F11': ('远程申请期限与负责人审批', {'E5':['负责人根据客户','常规申请在前一'],'I9':['远程办公申请按']}),
 'F12': ('远程使用公司设备，不因地点获批而允许个人设备/存储', {'E5':['远程办公原则上使用','员工不得因为获得远程'],'I3':['工作原则上使用公司'],'I9':['批准办公地点不等于']}),
 'F13': ('家庭/公共网络访问内部系统必须 VPN 与 MFA', {'I2':['通过公共或不可信网络','家庭网络未纳入']}),
 'F14': ('关键更新两工作日内完成，例外提前联系 IT', {'I3':['IT 推送的关键安全更新','确因现场业务']}),
 'F15': ('文件按实际内容分类，医疗材料属于保密信息', {'I4':['客户合同','对分类不确定','即使文件标题']}),
 'F16': ('资料负责人确定访问范围，最小必要权限', {'I4':['资料负责人决定访问范围']}),
 'F17': ('内部文档按人/组授权，不使用任何人可访问链接', {'I5':['内部协作使用','不得使用“任何人持链接']}),
 'F18': ('报销票据、账户和客户信息不得公开', {'X8':['不得将发票、账户信息']}),
 'F19': ('只能使用本人授权账号，办公网络也不得借账号', {'I1':['员工使用本人公司账号'],'I2':['在受管办公网络中']}),
 'F20': ('疑似恶意软件停止操作、断网、可信设备报告，不反复输入新密码', {'I8':['若怀疑当前设备','不要在疑似受控设备']}),
 'F21': ('安全事件报告 IT 并保留记录，不自行清除证据', {'I8':['立即通过可信渠道','不自行删除邮件'],'E9':['发现可疑邮件']}),
 'F22': ('普通差旅和外部培训行程结束十工作日内交费', {'X1':['普通差旅及外部培训行程']}),
 'F23': ('待补发票需期限内登记资料及预计补齐时间', {'X1':['因商家补票']}),
 'F24': ('公司卡支出仍需材料归集对账，不返还个人', {'X4':['使用公司卡同样','公司卡已支付']}),
 'F25': ('同一支出不得重复申报/由第三方承担后再报', {'X4':['一次消费不得'],'X8':['虚假票据、重复申报']}),
 'F26': ('退款应冲减实际费用，报销后也要退还或冲减', {'T7':['退款必须在结算时'],'X4':['退款、折扣和商家返还'],'X8':['报销完成后收到退款']}),
 'F27': ('业务取消退改损失提供证明审核，个人原因自担', {'T7':['业务安排变化','因客户变更','个人原因导致'],'X8':['业务原因产生的必要']}),
 'F28': ('国内普通商务住宿城市上限与按实报销，培训不得套用', {'T4':['境内普通商务出差','本制度中的一线城市','费用按实际发生额','外部培训住宿'],'X5':['交通、住宿等实报实销']}),
 'F29': ('培训住宿350按实非补贴，包住宿不得再领，不套普通500', {'X7':['外部培训住宿按','该标准适用于获批','主办方已包住宿'],'E6':['外出参训还需完成'],'T1':['不适用本制度的普通差旅住宿']}),
 'F30': ('普通差旅每日80及每餐扣30、最低零', {'T6':['境内普通商务出差餐费','客户或会议主办方'],'X5':['餐费补助按差旅制度规定']}),
 'F31': ('公司承担招待餐后扣个人差旅餐补', {'X6':['同一餐由公司承担'],'T6':['不得同时申报已由他方'],'X5':['餐费补助按差旅制度规定']}),
 'F32': ('紧急国内出差先负责人书面确认，下一工作日补单', {'T2':['紧急客户故障']}),
 'F33': ('可疑付款邮件用已知渠道核实，不用邮件所留电话', {'I7':['遇到要求紧急付款']}),
 'F34': ('离线交付申请 IT 登记加密介质，不用个人 U 盘', {'I6':['默认不使用个人','现场交付确需','未知来源']}),
 'F35': ('离职文件入团队空间、设备交 IT、HR 通知 IT 停账号', {'E9':['岗位调整或离职时'],'I9':['离职或岗位变动前','公司设备、加密介质','账号停用由']}),
 'F36': ('协作者退出由资料负责人及时撤销访问', {'I5':['项目结束或协作人员退出']}),
 'F37': ('病假返岗三工作日补记录，超过两日证明只交 HR', {'E4':['突发疾病无法工作','连续病假超过两天','医疗材料只提交']}),
 'F38': ('收费外训负责人及 HR 资格确认，预算负责人批费', {'E6':['参加收费的外部课程'],'X7':['收费的外部培训须先由']}),
 'F39': ('境外出差十工作日申请及三方批准', {'T8':['境外出差应提前']}),
 'F40': ('境外费用当地收据、支付及业务证明，外币实际结算', {'X2':['确实无法取得境内发票','外币金额需注明']}),
 'F41': ('招待事前负责人及预算批准，200每人每次，超额特别批准', {'X6':['客户或合作方招待','餐饮招待通常','预计超过该标准']}),
 'F42': ('培训/商务混合行程分日期、每晚用途及预算', {'X7':['培训与客户拜访合并'],'T1':['兼有培训与客户拜访'],'T4':['连续住宿跨越']}),
 'F43': ('混合活动同一天餐费经 HR/预算/财务确认一种方式', {'X7':['同一自然日兼有培训']}),
 'F44': ('预计超过总预算，说明增加原因并补预算审批', {'T2':['预计费用超出预算']}),
 'F45': ('普通住宿超限预订前报价原因晚数总额及预算/财务特别批准', {'T5':['展会期间房源紧张'],'X8':['普通差旅住宿例外']}),
 'F46': ('出差获批不豁免费用限额，超限需相应特别批准', {'E8':['批准出差不等于'],'X8':['超出已批准标准或预算']}),
 'F47': ('普通差旅/培训分别按各自条款处理，不可改费用类别规避', {'X8':['普通差旅住宿例外','拆分发票']}),
 'F48': ('外出参训需完成行程和工作交接登记', {'E6':['外出参训还需完成']}),
}

# Per-positive-chunk attribution; supplementary facts remain visible in the audit.
MAP = {
 1: {'E2':'01'}, 2:{'E3':'02'}, 3:{'E4':'03'}, 4:{'E7':'04'},
 5:{'X3':'05'}, 6:{'X2':'06'}, 7:{'T3':'07'}, 8:{'I1':'08 09','I2':'08'},
 9:{'E5':'10'}, 10:{'I3':'14'}, 11:{'I4':'15','I5':'17','X8':'18'},
 12:{'I8':'20 21','E9':'21'}, 13:{'X1':'22 23'}, 14:{'X4':'24 25','X8':'25'},
 15:{'T2':'32'}, 16:{'T7':'26 27','X4':'26','X8':'26 27'},
 17:{'T4':'28','X5':'28'}, 18:{'X7':'29','X8':'25'}, 19:{'T6':'30','X5':'30'},
 20:{'X8':'26','X4':'26'}, 21:{'I2':'13'}, 22:{'I7':'33'}, 23:{'I6':'34'},
 24:{'I1':'19','I2':'19','I4':'16'},
 25:{'E5':'10 11 12','I2':'13','I1':'08 19','I3':'12','I9':'11 12'},
 26:{'E9':'35','I5':'36','I9':'35'}, 27:{'E4':'37','I4':'15 16','I5':'17'},
 28:{'E6':'38','X1':'22','X7':'38'}, 29:{'X2':'40','T8':'39'},
 30:{'X6':'41 31','T6':'30 31','X5':'30 31'},
 31:{'X7':'29 42 43','T1':'42 29','T4':'28 42','E6':'29 48','X8':'25 47','T6':'30'},
 32:{'T2':'44','T5':'45','E8':'46','X8':'45 46 47'},
}
CORE = {
 1:'01',2:'02',3:'03',4:'04',5:'05',6:'06',7:'07',8:'08 09',9:'10',10:'14',
 11:'15',12:'20 21',13:'22 23',14:'24',15:'32',16:'26 27',17:'28',18:'29',
 19:'30',20:'26',21:'13',22:'33',23:'34',24:'19',25:'11 12 13',26:'35 36',
 27:'37 15 16 17',28:'38 22',29:'39 40',30:'41 31 30',31:'28 29 42 43',32:'44 45 46',
}
U = {
 33:(7,'T3','获批私家车出差的每公里金额','私家车与公共交通是不同事实；暂按同一交通费用政策对象保守关联，未声称原文给出里程单价。'),
 34:(6,'X2','公司实际发票全称和税号','同属境内开票信息，正文仅要求信息正确，未提供具体值。'),
 35:(5,'X3','审核后保证到账的最迟工作日数','批次安排不等于到账承诺。'),
 36:(29,'T8','本次新加坡已批专项预算中的酒店金额','申请规则不能推出某次已批预算。'),
 37:(3,'E4','个人本年度核定年假天数','年假额度与请假提前期是不同事实；暂按休假政策对象保守关联。'),
 38:(2,'E3','个人合同约定试用期月数','反馈频率与合同期限是不同事实；暂按试用期政策对象保守关联。'),
 39:(4,'E7','本年公司体检套餐每人预算','预约和承担范围规则不能推出预算数值。'),
 40:(21,'I2','公司批准 VPN 品牌及官方下载地址','接入义务不提供产品品牌和地址。'),
}

def ids(s):
    return ['F'+x for x in s.split()]

def build():
    annotations = read(ANNOTATIONS)
    inventory = {x['chunk_alias']:x for x in read(INVENTORY)['inventory']}
    assert digest(SNAPSHOT) == annotations['source_snapshot_sha256']
    assert len(inventory) == 38
    snapshot_chunks = {c['chunk_id']:c for c in read(SNAPSHOT)['chunks']}
    assert len(snapshot_chunks) == 38
    for chunk in inventory.values():
        frozen = snapshot_chunks[chunk['chunk_id']]
        assert all(chunk[k] == frozen[k] for k in ('content','file_id','file_name','chunk_index'))
        assert hashlib.sha256(chunk['content'].encode('utf-8')).hexdigest() == chunk['content_sha256']
    assert len(annotations['queries']) == 40
    assert {q['query_id'] for q in annotations['queries']} == {f'BC01-Q{n:03}' for n in range(1,41)}
    facts = []
    for fid,(statement,sources) in FACTS.items():
        evidence = []
        for alias,fragments in sources.items():
            chunk = inventory[alias]
            sentences = re.findall(r'[^。\n]+[。]?', chunk['content'])
            quotes = []
            for fragment in fragments:
                hits = [s for s in sentences if fragment in s]
                assert len(hits) == 1, (fid,alias,fragment,hits)
                if hits[0] not in quotes:
                    quotes.append(hits[0])
            evidence.append({'chunk_alias':alias,'chunk_id':chunk['chunk_id'],
                             'content_sha256':chunk['content_sha256'],'quotes':quotes})
        facts.append({'fact_id':fid,'policy_fact':statement,'evidence':evidence,'review_status':'PENDING'})
    queries = []
    for source in annotations['queries']:
        n = int(source['query_id'][-3:])
        assert source['coverage_reviewed'] and len(source['judgments']) == 38
        assert source['human_coverage_review']['status'] == 'APPROVED'
        assert source['question_review_status'] == 'APPROVED'
        assert hashlib.sha256(source['query_text'].encode('utf-8')).hexdigest() == source['query_text_sha256']
        assert {j['chunk_id'] for j in source['judgments']} == set(snapshot_chunks)
        assert all(j['chunk_id'] == inventory[j['chunk_alias']]['chunk_id'] for j in source['judgments'])
        assert all(j['human_review_status']=='APPROVED' for j in source['judgments'])
        mapping = {a:ids(fs) for a,fs in MAP.get(n,{}).items()}
        positive = {j['chunk_alias'] for j in source['judgments'] if j['human_grade']>=2}
        assert set(mapping)==positive,(n,positive,mapping)
        used = set(f for fs in mapping.values() for f in fs)
        core = ids(CORE.get(n,''))
        premise = ['F10'] if n==25 else []
        assert set(core+premise)<=used
        for alias,fs in mapping.items():
            assert all(alias in FACTS[f][1] for f in fs),(n,alias,fs)
        q = {'query_id':source['query_id'],'query_text':source['query_text'],
             'query_text_sha256':source['query_text_sha256'],
             'category':source['human_query_category'],'answerable':source['human_answerable'],
             'core_facts':core,'premise_facts':premise,
             'supporting_facts':sorted(used-set(core+premise)),
             'positive_chunk_fact_mapping':mapping,'review_status':'PENDING'}
        if n in U:
            anchor,alias,missing,reason = U[n]
            q['unanswerable_association']={'with_query':f'BC01-Q{anchor:03}',
                'policy_anchor':alias,'missing_requested_value':missing,'reason':reason}
            assert not positive
            assert [j['chunk_alias'] for j in source['judgments'] if j['human_grade']==1]==[alias]
        queries.append(q)
    by_id = {q['query_id']:q for q in queries}
    parent = {qid:qid for qid in by_id}
    def root(qid):
        while parent[qid]!=qid:
            qid=parent[qid]
        return qid
    edges=[]
    def join(a,b,reason):
        parent[root(b)]=root(a)
        edges.append({'left':a,'right':b,'reason':reason})
    for i,a in enumerate(queries):
        for b in queries[i+1:]:
            ac=set(a['core_facts']+a['premise_facts']); bc=set(b['core_facts']+b['premise_facts'])
            shared=(ac & (bc|set(b['supporting_facts']))) | (bc & set(a['supporting_facts']))
            if shared:
                join(a['query_id'],b['query_id'],'shared core/premise fact: '+','.join(sorted(shared)))
    for q in queries:
        if 'unanswerable_association' in q:
            join(q['query_id'],q['unanswerable_association']['with_query'],'conservative U policy association')
    groups=defaultdict(list)
    for q in queries:
        groups[root(q['query_id'])].append(q['query_id'])
    dev_numbers={3,5,7,8,9,11,12,17,18,19,21,24,25,27,30,31,33,35,37,40}
    families=[]
    for index,members in enumerate(sorted(groups.values(),key=lambda x:min(x)),1):
        splits={'Dev' if int(q[-3:]) in dev_numbers else 'Test' for q in members}
        assert len(splits)==1,('split family',members)
        family={'family_id':f'FF{index:02}','query_ids':members,'draft_split':splits.pop(),
                'core_facts':sorted({f for q in members for f in by_id[q]['core_facts']}),
                'review_status':'PENDING'}
        families.append(family)
        for qid in members:
            by_id[qid].update(family_id=family['family_id'],draft_split=family['draft_split'])
    pilot_overlap=[
        {'pilot_query':'PILOT-CQ-001','overlap':'source_only','facts':[], 'explanation':'协作时段与 Q001 到岗/午休/下班分属 E2 内不同规则。'},
        {'pilot_query':'PILOT-CQ-002','overlap':'source_only','facts':[], 'explanation':'密码长度/复用与 MFA、账号借用不同；同为 I1 来源。'},
        {'pilot_query':'PILOT-CQ-003','overlap':'source_only','facts':[], 'explanation':'考勤补记与 Q001 作息是 E2 内不同规则。'},
        {'pilot_query':'PILOT-CQ-004','overlap':'core','facts':['F21'], 'explanation':'异常 MFA 的 IT 报告与证据保留，和 Q012 的安全事件处置有共同核心事实。'},
        {'pilot_query':'PILOT-CQ-005','overlap':'core','facts':['F28','F29'], 'explanation':'上海培训住宿上限及不得套普通差旅标准；相关连通组整体入 Dev。'},
        {'pilot_query':'PILOT-CQ-006','overlap':'core','facts':['F08','F10','F11','F13'], 'explanation':'远程资格、申请、VPN/MFA；相关连通组整体入 Dev。'},
    ]
    pilot_facts={f for p in pilot_overlap for f in p['facts']}
    for q in queries:
        q['pilot_core_overlap_facts']=sorted(pilot_facts & set(q['core_facts']+q['premise_facts']+q['supporting_facts']))
        if q['pilot_core_overlap_facts']:
            assert q['draft_split']=='Dev'
    counts={}
    for split in ('Dev','Test'):
        subset=[q for q in queries if q['draft_split']==split]
        counts[split]={'total':len(subset),'answerable':sum(q['answerable'] for q in subset),
                       'unanswerable':sum(not q['answerable'] for q in subset),
                       'answerable_categories':dict(Counter(q['category'] for q in subset if q['answerable'])),
                       'unanswerable_categories':dict(Counter(q['category'] for q in subset if not q['answerable']))}
        assert (counts[split]['answerable'],counts[split]['unanswerable'])==(16,4)
    fact_cross=[]; chunk_cross=[]
    for fid in FACTS:
        sides={s:[q['query_id'] for q in queries if q['draft_split']==s and fid in q['core_facts']+q['premise_facts']+q['supporting_facts']] for s in ('Dev','Test')}
        if all(sides.values()):
            assert all(fid not in by_id[q]['core_facts']+by_id[q]['premise_facts'] for qs in sides.values() for q in qs)
            fact_cross.append({'fact_id':fid,'kind':'support_only',**sides})
    for alias in inventory:
        sides={s:[q['query_id'] for q in queries if q['draft_split']==s and alias in q['positive_chunk_fact_mapping']] for s in ('Dev','Test')}
        if all(sides.values()):
            chunk_cross.append({'chunk_alias':alias,**sides})
    normalized=defaultdict(list)
    for q in queries:
        normalized[re.sub(r'\s+','',q['query_text'])].append(q['query_id'])
    duplicates=[v for v in normalized.values() if len(v)>1]
    assert not duplicates
    draft={'artifact_version':'fact-split-draft-0.1','created_date':'2026-09-14',
        'status':'DRAFT','human_family_split_review':'PENDING','dataset_promotion':'PENDING',
        'benchmark_ready':False,'benchmark_executed':False,'corpus_expanded':False,
        'source_annotations':{'path':'../benchmark-candidate-0.1/reviewed-annotations-0.2.json','sha256':digest(ANNOTATIONS)},
        'source_inventory_sha256':digest(INVENTORY),'source_pilot_sha256':digest(PILOT),
        'source_snapshot_sha256':digest(SNAPSHOT),'snapshot_id':annotations['snapshot_id'],
        'method':'Connect shared core/premise facts including core-support overlaps; union each multi-fact query; associate U with policy anchors; audit support-only and chunk overlaps separately.',
        'facts':facts,'queries':queries,'families':families,'family_edges':edges,'counts':counts}
    audit={'status':'DRAFT','automated_structural_validation':'PASS',
        'semantic_fact_review':'PENDING','source_annotations_unchanged':True,
        'query_count':len(queries),'human_grade_count':sum(len(q['judgments']) for q in annotations['queries']),
        'family_count':len(families),'largest_family_query_count':max(len(f['query_ids']) for f in families),
        'cross_split_core_fact_edges':[],'cross_split_support_only_facts':fact_cross,
        'cross_split_positive_chunks':chunk_cross,'exact_normalized_duplicate_questions':duplicates,
        'semantic_dedup_review':'PENDING','pilot_overlap':pilot_overlap,
        'all_38_source_chunks_exposed_in_pilot_review':True,
        'test_is_blind_or_source_independent':False,
        'target_gap':{'answerable_missing':8,'unanswerable_missing':0,
                      'per_split_answerable_missing':4,'smaller_dataset_exception':'NOT_APPROVED'},
        'limitations':['Semantic fact boundaries are proposed, not Human-approved.',
            'No core-fact crossing is conditional on this mapping; does not prove absence of leakage.',
            'All source texts were reviewed during Pilot; Test is not unseen policy/corpus.',
            'Shared positive chunks and support-only rules can aid retrieval across splits.',
            '32A/8U is below the 40A/8U contract target; no readiness/promotion claim.']}
    return draft,audit

def render(draft,audit):
    short=lambda q:q.removeprefix('BC01-')
    facts={f['fact_id']:f for f in draft['facts']}
    detail=['# 核心事实与逐题归属草案','',
        '所有事实边界、family 和 split 均待人工审阅。原人工等级和 coverage 不变。事实编号不是新的相关性标签。', '',
        '核心事实 = 回答所必需的政策决定；题干前提也参与隔离。补充事实 = 支持解释但不是本题直接所问；若它是另一题核心，也合并。引用保留完整句子作为上下文，事实范围以“政策事实”描述为准。','',
        '## 逐题映射','', '| 题号 / 草案 | 已批准问题 | 核心事实 | 题干前提 | 补充事实 / U 关联 | 正证据归因 |','|---|---|---|---|---|---|']
    for q in draft['queries']:
        supplementary=','.join(q['supporting_facts']) or '—'
        if 'unanswerable_association' in q:
            u=q['unanswerable_association']
            supplementary=f"关联 {short(u['with_query'])} / {u['policy_anchor']}（grade 1）；缺失：{u['missing_requested_value']}。{u['reason']}"
        mapping='；'.join(a+':'+','.join(fs) for a,fs in q['positive_chunk_fact_mapping'].items()) or '无 grade ≥2'
        detail.append(f"| {short(q['query_id'])} / {q['family_id']} / {q['draft_split']} | {q['query_text']} | {','.join(q['core_facts']) or '—'} | {','.join(q['premise_facts']) or '—'} | {supplementary} | {mapping} |")
    detail+=['','## 事实词典与逐字证据','']
    for f in draft['facts']:
        detail += [f"### {f['fact_id']} {f['policy_fact']}",'']
        for e in f['evidence']:
            detail += [f"来源 [{e['chunk_alias']}](../benchmark-candidate-0.1/evidence-inventory.md#{e['chunk_alias'].lower()}) · chunk `{e['chunk_id']}`",'']
            detail += ['> '+quote for quote in e['quotes']]
            detail += ['']
    overview=['# Dev/Test 核心事实划分草案 0.1','',
        '**DRAFT · 2026-09-14 · 仅供审阅，尚未冻结或批准。** 输入为已通过的 40 题、1,520 项等级和全快照 coverage；不再重审这些标签。本轮未扩充语料、未运行 Retrieval/Benchmark。','',
        f"按核心政策事实和不可回答题的保守政策关联，得到 **{len(draft['families'])} 个 family，最大 {audit['largest_family_query_count']} 题**。建议 Dev/Test 各 20 题（16 Answerable +4 Unanswerable）。划分基于语义与 Pilot 暴露，不使用检索分数。",'',
        '| 集合 | Direct Fact（A） | Paraphrase（A） | Distractor（A） | Multi-chunk（A） | 不可回答 | 合计 |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for s,c in draft['counts'].items():
        vals=[c['answerable_categories'].get(k,0) for k in ['Direct Fact','Paraphrase','Distractor','Multi-chunk']]
        overview.append('| '+s+' | '+' | '.join(map(str,vals+[c['unanswerable'],c['total']]))+' |')
    overview += ['', '## 建议分组', '', '| Family | 题号 | 核心政策事实（缩写） | 建议 |', '|---|---|---|---|']
    family_labels = [
        '正常作息', '入职支持 / 试用反馈；关联合同期限缺失',
        '计划请假提前期；关联个人年假额度缺失', '体检预约 / 加项；关联预算缺失',
        '付款批次 / 账户；关联到账承诺缺失', '境内发票材料；关联抬头税号缺失',
        '交通席位 / 升级；关联私车里程单价缺失',
        '远程资格 / 申请 / 设备 / 接入，账号授权，医疗与文件分类权限',
        '关键安全更新期限与例外', '恶意软件与安全事件处置',
        '行程费用提交期限 / 待补发票，外训报名预算审批', '公司卡归集与个人返款',
        '紧急出差书面确认与补单', '退改损失与报销前后退款冲减',
        '普通 / 培训住宿，混合行程，餐补与业务招待',
        '可疑付款邮件独立核实', '离线介质申请与归还',
        '离职文件 / 设备 / 账号与协作权限撤销',
        '境外审批与费用证明；关联专项预算缺失', '预算增加与酒店超限特别审批',
    ]
    assert len(family_labels) == len(draft['families'])
    for f in draft['families']:
        labels=family_labels[int(f['family_id'][2:])-1]
        overview.append(f"| {f['family_id']} | {', '.join(map(short,f['query_ids']))} | {labels} | {f['draft_split']} |")
    overview += ['', '## 重点审阅边界', '',
        '1. **同块不同事实是否可以分开。** I3 的公司设备要求（Q025）与更新期限（Q010）；E9/I9 的安全事件/远程条款与离职交接（Q026）；E4 的请假提前期（Q003）与病假医疗处理（Q027）。这些不是简单随机拆题。',
        '2. **多事实题仍整组保留。** Q025 连接远程、设备、接入；Q027 连接病假、分类、权限；Q031 连接培训/普通住宿和混合行程。核心与补充事实相交也合并，因此没有为了均衡强拆这些连接。',
        '3. **不可回答题按政策对象保守归组。** 尤其 Q033→Q007、Q037→Q003、Q038→Q002 是保守关联，不是声称两题问同一事实。8 个缺失值保持不可回答。',
        '4. **Pilot 暴露相关组放 Dev。** 已用到的远程接入、培训住宿、安全事件报告事实及其连接组全部入 Dev。其余可移动组中，Q003/Q037 放 Dev 可减少 E4 跨侧共享；Q005/Q035、Q007/Q033 放 Dev 用于规模/类别平衡；Q006 与 Q029 都放 Test 可减少 X2 共享。这是确定性人工草案，不声称全局最优。',
        '', '## 仍需接受或调整的局限', '',
        f"- 在本次映射下，核心/前提事实跨侧连接为 0；仍有 **{len(audit['cross_split_positive_chunks'])} 个正证据 chunk** 跨侧共享，另有 **{len(audit['cross_split_support_only_facts'])} 条仅补充事实**跨侧共享。详见重叠表，不能称为完全无泄漏。",
        '- 所有 38 块原文曾在 Pilot coverage 中供审阅；Test 不是盲测集，也不是新语料泛化测试。语义边界获批不消除共享文本带来的检索熟悉度。',
        '- 当前 32A+8U 比契约 40A+8U 少 8 道可回答题，每侧少 4 道；可回答类别尚非每侧各 5 题。小规模版本例外未获批，本轮按指令不补题或扩语料。',
        '- 同政策家族内有相近问题（如 Q016/Q020 退款前后、Q019/Q030 餐费扣减），保留不同任务情景但仍待语义去重审阅；未因共享事实而删除已审题。',
        '', '## 审阅入口与决定范围','',
        '先审上面四项边界和 family 表，有异议只需指出 family/题号及调整理由；无需再逐条确认 1,520 项等级。分组、划分和局限可批量审阅。规模例外、最终语料选择、去重与 dataset promotion 是后续独立决定，当前全部保持待定。',
        '', '- [逐题归属、补充事实与逐字证据](fact-mapping.md)',
        '- [Pilot / 跨集合重叠审计](overlap-review.md)',
        '- [机器可读划分](split-draft.json) · [审计数据](audit.json) · [核验记录](verification.md)',
        '', '结构核验只验证映射自洽及来源绑定，不能代替事实边界的人工判断。']
    overlap=['# Pilot 暴露与共享证据审计','', '**草案，语义审阅 PENDING。**', '',
        '## Pilot 核心事实核对','', '| Pilot | 类型 | 事实 | 判断 |','|---|---|---|---|']
    for p in audit['pilot_overlap']:
        overlap.append(f"| {p['pilot_query']} | {p['overlap']} | {','.join(p['facts']) or '—'} | {p['explanation']} |")
    overlap += ['', 'Pilot 原题来源：[已审阅 Pilot packet](../pilot-snapshot-01-annotation-packet-draft.md)。本表是针对原题政策需求的语义映射，非模型记忆测量。全快照原文暴露覆盖所有 38 块。','',
        '## 两侧共享 grade ≥2 文本块','', '| Chunk | Dev | Test |','|---|---|---|']
    for r in audit['cross_split_positive_chunks']:
        overlap.append(f"| {r['chunk_alias']} | {', '.join(map(short,r['Dev']))} | {', '.join(map(short,r['Test']))} |")
    overlap += ['', '这些块内的不同条款仍可能让开发者/检索系统熟悉 Test 证据。共享块不能作为集合独立性的证明；完整 38 块在两侧都可检索，表中只计算两侧均有人工正等级的块。','',
        '## 仅补充事实跨侧','', '| 事实 | Dev | Test |','|---|---|---|']
    for r in audit['cross_split_support_only_facts']:
        overlap.append(f"| {r['fact_id']} {facts[r['fact_id']]['policy_fact']} | {', '.join(map(short,r['Dev']))} | {', '.join(map(short,r['Test']))} |")
    overlap += ['', 'F25 的一般不重复申报规则在 Q014 是公司卡归集的补充，在 Q018/Q031 是培训住宿/混合费用的补充。F47 的分类适用及不得改类别规避在 Q031/Q032 均作为补充。本草案允许这种仅补充规则共享；如 Human 将其视为共同核心证据，需要合并相关 family 并重算划分，不能只改状态为通过。','',
        'Q018 的获批、Q031 的无超限特别批准、Q032 的出差已批是已知场景，本草案不把它们自动等同于询问批准流程；Q025 明说已转正且岗位合适，直接复述 F10，因此保留事实前提连接。这些区分也属于待审语义边界。','',
        '## 去重与质量边界','',
        '规范化空白后的同文问题为 0。语义去重仍待审；退款的报销前后、公司付餐与客户供餐、远程资格与完整申请流程等近邻已尽量留在同 family。没有基于指标挑题，也没有运行指标。']
    verification=['# 草案结构核验','',
        '执行日期：2026-09-14；执行器为本目录 build_draft.py（Python 标准库）。这是本地文件核验，不调用 Runner、模型或检索。','',
        '复现：在项目根目录执行 `python docs/v2/evaluation/fact-split-draft-0.1/build_draft.py --check`。','',
        '- PASS：来源 annotations、snapshot、inventory、Pilot 文件 SHA-256 绑定；快照与已审标注记录一致。',
        '- PASS：40 题唯一归属；每题 38 项已批准等级，coverage 已通过；所有人工正证据均有事实归因。',
        '- PASS：事实引用均逐字来自指定冻结块；每条归因的 chunk 与事实来源一致。',
        '- PASS：核心/前提与其他题核心/补充相交时合并；多事实题未拆分；U 关联与 grade 1 锚点一致。',
        '- PASS：family 不跨侧；Pilot 已知核心事实相交题全部在 Dev；两侧各 16A+4U。',
        '- PASS：补充事实跨侧与人工正证据块跨侧显式输出；空白规范化同文问题为 0。',
        '- PASS：生成结果可用 --check 逐文件复核，事实/划分/晋升始终保持待审，benchmark_ready=false。',
        '', '该核验不证明事实划界正确、语义完全去重或零泄漏。原人工标注文件只读；所有新内容均为派生草案。']
    dumps=lambda x:json.dumps(x,ensure_ascii=False,indent=2)+'\n'
    return {'split-draft.json':dumps(draft),'audit.json':dumps(audit),
            'README.md':'\n'.join(overview)+'\n','fact-mapping.md':'\n'.join(detail)+'\n',
            'overlap-review.md':'\n'.join(overlap)+'\n','verification.md':'\n'.join(verification)+'\n'}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--check',action='store_true',help='Read-only validation and artifact drift check')
    args=parser.parse_args()
    before={p:digest(p) for p in [ANNOTATIONS,INVENTORY,PILOT,SNAPSHOT]}
    draft,audit=build()
    for name,content in render(draft,audit).items():
        path=HERE/name
        if args.check:
            assert path.read_text(encoding='utf-8')==content,('artifact drift',name)
        else:
            path.write_text(content,encoding='utf-8',newline='\n')
    assert all(digest(p)==value for p,value in before.items()),'Source changed'
    print(json.dumps({'result':'PASS','mode':'check' if args.check else 'build',
                      'families':audit['family_count'],'largest_family':audit['largest_family_query_count'],
                      'counts':draft['counts'],'shared_positive_chunks':len(audit['cross_split_positive_chunks']),
                      'support_only_cross_facts':len(audit['cross_split_support_only_facts'])},ensure_ascii=False))

if __name__=='__main__':
    main()
