"""Render Markdown review views from candidates.json. Never edits Human decisions."""
import argparse
from collections import Counter
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def render(data):
    outputs = {}
    inv = ['# 冻结证据正文索引', '',
        '来源为历史 snapshot.json；以下 38 块逐字复制，短别名仅便于阅读，机器身份仍为 chunk_id。',
        '源码与快照 SHA-256 由 verify_packet.py 核验；当前未回读实时 Chroma 或重新入库。', '']
    for c in data['inventory']:
        inv += [f'<a id="{c["chunk_alias"].lower()}"></a>', f'## {c["chunk_alias"]} — {c["file_name"]} / chunk {c["chunk_index"]}', '',
            f'chunk_id：`{c["chunk_id"]}`；file_id：`{c["file_id"]}`。', '',
            f'content_sha256：`{c["content_sha256"]}`', '', '```text', c['content'], '```', '']
    outputs['evidence-inventory.md'] = '\n'.join(inv)
    for batch in range(4):
        selected = data['queries'][batch*10:(batch+1)*10]
        lines = [f'# 人工审阅批次 {batch+1} — {selected[0]["query_id"]}～{selected[-1]["query_id"]}', '',
            '[审阅入口](README.md) · [人工决定表](human-decisions.md) · [完整证据正文](evidence-inventory.md)', '',
            '**以下所有问法、类别、可回答性、等级、family/split 与答案提纲均为建议。没有任何新 Human Ground Truth。**', '',
            '每题先检查信息需求和问法，再对照 38 行及链接正文审核全部快照；不要只看非零行。',
            'Grade 0 行是显式 LLM 建议，Human grade 仍为空；未进行 Human coverage 确认。',
            '答案提纲仅帮助核对检索证据需求，不是生成质量评估的标准答案。', '']
        for q in selected:
            lines += [f'<a id="{q["query_id"].lower()}"></a>', f'## {q["query_id"]}', '',
                f'**候选问题：{q["query_text"]}**', '',
                f'建议类别：{q["suggested_query_category"]}；建议可回答：{q["suggested_answerable"]}；建议 family：{q["evidence_family_id"]}；建议 split：{q["suggested_split"]}。', '',
                f'信息需求：{q["information_need"]}', '', f'证据支持的答案提纲（待审）：{q["suggested_answer_outline"]}', '',
                '需要特别检查：', '']
            lines += ['- '+flag for flag in q['review_flags']]
            if q['pilot_overlap']:
                lines += ['- Pilot 既有暴露/相关题：'+', '.join(q['pilot_overlap'])+'。不继承其人工批准，正式题不与这些事实跨 split。']
            lines += ['', '**建议的 Grade ≥ 2 集合（不是检索返回）：** '+(', '.join(j['chunk_alias'] for j in q['judgments'] if j['suggested_grade'] >= 2) or '空；需 Human 确认无实质正证据。'), '',
                '| 证据正文 | 建议等级 | Human 等级 | 建议理由 |', '|---|---:|---|---|']
            for j in q['judgments']:
                lines.append(f'| [{j["chunk_alias"]}](evidence-inventory.md#{j["chunk_alias"].lower()}) | {j["suggested_grade"]} | 待审 | {cell(j["suggestion_rationale"])} |')
            lines += ['', '人工应决定：保留/改写/删除；类别；可回答性；逐块等级变更及理由；是否已检查全快照且无遗漏正证据；family/split。',
                '请在 [人工决定表](human-decisions.md#'+q['query_id'].lower()+') 留下结论。当前所有决定均为 PENDING。', '']
        outputs[f'review-batch-{batch+1:02}.md'] = '\n'.join(lines)
    lines = ['# Evidence-family 与 Dev/Test 待审划分', '',
        '这是候选检查结果，不是 Human-approved split，也不是没有语义泄漏的证明。', '',
        '先将所有共享 suggested grade≥2 chunk 的题连接，再对 Multi-chunk 做传递合并；无答案题归入其所问政策的家族。',
        '这种方法比契约的“同一核心事实”更保守：同一 chunk 可含不同事实，因此可能过度合并。不得通过降低相关等级来拆组。',
        'Human 可以审阅并细化核心事实，但必须记录事实边界与理由，检查跨 split 的实质重叠；结构检查不能代替该判断。', '',
        '| 家族 | 建议 split | A/U 数 | 题目 | 实质证据 / 缺失事实归属 |', '|---|---|---|---|---|']
    for f in data['families']:
        qs = [q for q in data['queries'] if q['query_id'] in f['query_ids']]
        a = sum(q['suggested_answerable'] for q in qs)
        lines.append(f'| {f["evidence_family_id"]} | {f["suggested_split"]} | {a}/{len(qs)-a} | '+', '.join(q['query_id'] for q in qs)+' | '+', '.join(f['policy_chunk_aliases'])+' |')
    lines += ['', '## 与质量目标的差额', '', '| split | Answerable | Unanswerable | Direct Fact / Paraphrase / Distractor / Multi-chunk（仅 Answerable） |', '|---|---:|---:|---|']
    for split in ('Dev', 'Test'):
        qs = [q for q in data['queries'] if q['suggested_split']==split]
        counts = Counter(q['suggested_query_category'] for q in qs if q['suggested_answerable'])
        a = sum(q['suggested_answerable'] for q in qs)
        lines.append(f'| {split} | {a} | {len(qs)-a} | '+ ' / '.join(str(counts[c]) for c in ('Direct Fact','Paraphrase','Distractor','Multi-chunk'))+' |')
    lines += ['', '总计 32 Answerable（四类各 8）+8 Unanswerable；契约目标为 40+8，少 8 道 Answerable，四类各少 2。',
        '每个 split 的目标是 20+4、Answerable 每类 5；当前 Dev 为 27+4，Test 为 5+4。Test 没有可回答的 Paraphrase/Multi-chunk，不能支持这些类别的 held-out 比较。', '',
        '## 核心诊断与处理选择', '',
        '- F03 含 30 题：Q011 用费用材料的数据保护连接 X8 与 I4/I5；Q026/Q027 连接安全、离职与假期；Q028/Q031/Q032 连接培训、差旅和报销。这是语料关联密集的诊断，不是 30 个独立事实样本。',
        '- Pilot 相关的 F01/F03 暂放 Dev；历史 Pilot 已参与契约及工具设计。Test 只是未来调参的拟议隔离，不能声称对标注者/本次助手完全未见。',
        '- Q025 与 Pilot-CQ-006 接近，应优先决定删去扩展题或替换，不凭题数宣称新增独立覆盖。',
        '- 建议先完成问题质量审阅，再按核心事实细化大组并审核泄漏；如果仍缺独立 Test 内容，另行扩充原创语料、生成新快照，再补题和重新映射标注。',
        '- 当前快照所有实体是虚构组织；问法/判断由同一 LLM 辅助产生，且 primary reviewer 为单人。未评估真实企业用户分布、长文档、OCR 和跨语言泛化。',
        '- 八道 Unanswerable 都是有相邻政策但缺具体数值/产品资料的弱相关边界，不代表全部不可回答场景，更不能证明生成层会正确拒答。',
        '- 现阶段不要冻结此 split。若最终接受低于目标的规模或类别缺口，须由 Human 明确批准并保留这些局限。', '']
    outputs['split-review.md'] = '\n'.join(lines)
    return outputs


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true', help='Check views without writing.')
    args = parser.parse_args()
    data = json.loads((HERE / 'candidates.json').read_text(encoding='utf-8'))
    for name, content in render(data).items():
        content = content.rstrip()+'\n'
        path = HERE / name
        if args.check:
            if not path.exists() or path.read_text(encoding='utf-8') != content:
                raise SystemExit('STALE: '+name)
        else:
            path.write_text(content, encoding='utf-8')
    print('Review views match candidates.json.' if args.check else 'Rendered 6 Markdown views; Human decisions untouched.')
