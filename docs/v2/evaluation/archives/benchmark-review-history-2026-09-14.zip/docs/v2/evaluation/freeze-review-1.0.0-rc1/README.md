# 正式版本冻结审阅包 — 1.0.0-rc1

**本包已备供最终审阅；正式冻结、promotion 和 Benchmark 执行均未获批准。**

候选版本标识：`novatech-retrieval-benchmark-1.0.0-rc1`。这是审阅候选，不是已发布的 1.0.0。保留 BC01-Q001–Q040 稳定题号，不因打包更名，也不纳入 PILOT-CQ-001–006。名称中的 benchmark 表示预期用途，不代表已经具备执行授权。

## 待冻结的具体内容

| 内容 | 已审范围 |
|---|---|
| 语料 | novatech-pilot-0.1；员工手册、差旅、报销、信息安全四份原文 |
| 快照 | t2001-novatech-pilot-01；原冻结 38 chunks，内容和 ID 不变 |
| 题目 | 40 题：32 Answerable +8 Unanswerable；7 项已批问法修订保留 |
| 等级 | 全量 1,520 项显式 Human grades；0/1/2/3 分布 1446/8/21/45；19 项历史等级变更来源保留 |
| Coverage | 全部 40 题完整快照覆盖与无遗漏正证据已批准 |
| 核心事实 / 家族 | 48 个事实单元、20 个 family，最大 8 题；已批准 |
| Dev/Test | 各 16A+4U；可回答四类分别为 4/3/5/4 与 4/5/3/4 |
| 去重 | SD01–SD20 七批批准全部保留；无删除/合并/改写 |
| 规模 / 最终语料 | SC01/SC02 批准当前规模差额、类别缺口及语料选择 |
| 最终版本批准 | **PENDING**；不得由前述分项决定推导为已冻结 |

四类顺序为 Direct Fact、Paraphrase、Distractor、Multi-chunk。

## 文件入口

- [dataset.json](dataset.json)：按现有 Runner schema 1 整理的完整候选输入。逐题及逐 judgment 为真实已批状态；数据集级 review 保持 PENDING。
- [manifest.json](manifest.json)：文件 SHA-256、源路径与 hash、Git HEAD/工作树、V1 tag 和评估工具 hash。未提交文件不冒充已提交版本。
- [verification.json](verification.json)：内容与来源核验、计数及执行批准门禁的预期拦截结果。
- [evidence/annotations.json](evidence/annotations.json)、[原建议](evidence/initial-candidates.json)、[人工标注决定](evidence/annotation-decisions.md)：完整标注、原问法/建议与改动依据。
- [分组](evidence/split.json)、[分组批准](evidence/split-decision.md)、[重叠审计](evidence/overlap-audit.json)：核心事实和已接受的交叉证据局限。
- [去重决定](evidence/dedup-decisions.md)、[规模与语料批准](evidence/size-corpus-decision.md)：后续真实批准来源；所附早期文件中的待定状态只表示其历史时点。
- [snapshot.json](evidence/snapshot.json)、[语料来源说明](evidence/corpus-provenance.md)、[契约](evidence/contract.md)：冻结的原始来源及约束。四份政策原文在 `evidence/corpus/`，本目录内其余审阅文件不作为检索语料。

## 已知局限与使用边界

这是单一虚构组织的中文合成政策集，不代表真实员工问题、生产发生率、大型知识库或跨企业泛化。32A+8U 低于 40A+8U 质量目标，缺口虽获批接受，契约目标没有被改写；单类别每侧仅 3–5 道可回答题，Dev/Test 类别权重不同。

所有原文曾在 Pilot 审阅中暴露。两侧仍共享 7 个正证据块及 2 条仅补充规则，Test 非盲测、非独立语料，后续不得用于反复调参。事实边界及去重通过不等于样本相互独立或零泄漏。

8 道不可回答题均是存在 grade 1 邻近政策但缺少所求信息的场景，不涵盖所有负例类型；从主 Answerable Recall/MRR/nDCG 聚合中排除并单列，不能据此证明生成拒答能力。

快照保留历史摄入配置、模型文件 hash 与包版本，但不包含可移植的完整 Chroma 向量库。重新摄入会产生新 UUID，需核对身份及审阅影响。当前没有验证实时模型、索引或存储；快照中的旧模型证据不代表当前运行环境已就绪。V1 的 metadata/page 追溯与同分顺序局限继续有效。

## 本轮核验的含义

运行 `python docs/v2/evaluation/freeze-review-1.0.0-rc1/prepare.py --check` 可只读复核本包和原来源。

核验检查逐字原题、全部 judgment 与快照映射、coverage 和真实批准字段、家族不跨侧、来源 hash、派生文件与上游一致性。然后单独调用纯数据校验函数，确认当前文件被 `dataset promotion: review not APPROVED` 拦截。这是**预期门禁行为**，不是 Benchmark 失败，也不是完整执行校验已经放行。未伪造批准来绕过门禁，未调用 Runner/metrics/retrieval/模型。

`manifest.json` 锁定本包构建时的 dataset、README、生成/检查脚本与全部证据；manifest 自身和随后生成的 verification.json 不参与其自身 hash，避免循环。正式批准必须绑定 manifest 与 dataset 的具体 hash；后续内容变化须重建版本并重新核对批准范围。

## 最终批准将覆盖什么

本轮仅提交审阅，无需重新审批已有分项。最终 Human 决定应明确：本候选对应的内容和来源是否作为首个正式版本冻结、是否批准 dataset promotion，以及确切版本标识。即使批准冻结和 promotion，T2003 的执行仍需独立授权与实时环境就绪核查。

最终批准记录目前为空：**PENDING**。收到真实决定后再记录实际日期、原文和文件 hash，并据决定生成正式发布版本；本包不预填未来批准人或虚构批准引用。
