# 第二轮批次 4：Q021–Q030 证据等级与完整覆盖

版本：`R2-B04-0.1`；绑定 `novatech-pilot-0.1` / `t2001-novatech-pilot-01`（38 chunks）。
本批全部等级为待审建议，Human grade=null，coverage_reviewed=false。使用 [Human ledger](human-decisions.md) 批准的问法，含 Q027 改写。
原 Candidate 0.1 保留；八处修订均为新的 LLM 建议，未借用其他题目批准。

## 已批准的问题

- **BC01-Q021**：在家用的是我自己设密码的 Wi-Fi，访问公司内部系统就可以不连 VPN 吗？
- **BC01-Q022**：邮件显示是领导，让我马上修改收款账户，还留了核实电话，照着邮件里的号码打过去就能确认靠谱吗？
- **BC01-Q023**：客户现场没网，我能把工作文件拷到自己的 U 盘交付吗？如果确实需要离线介质该怎么做？
- **BC01-Q024**：我人在公司受管办公网络，同事让我借他的账号临时查资料，这样可以省去权限申请吗？
- **BC01-Q025**：已转正且岗位适合远程办公，我想下周固定在家工作两天：何时申请、谁批准，获批后用什么设备、怎样接入内部系统？
- **BC01-Q026**：离职前工作文件、电脑和认证设备分别怎么交接，谁办理账号停用，旧合作链接的权限又由谁撤销？
- **BC01-Q027**：连续病假三天，返岗后记录和医疗证明要怎样提交？人力资源部接收这些材料后，应如何分类并控制内部访问权限？
- **BC01-Q028**：参加收费的外部课程，从报名到预算应找谁确认？参训行程结束后多久提交费用？
- **BC01-Q029**：去境外拜访客户，要提前多久申请、经谁批准？当地拿不到境内发票时，用什么凭证说明外币费用？
- **BC01-Q030**：我在境内普通出差期间用公司费用请客户吃饭，招待应事先经谁批准、通常每人上限多少，参加这餐的员工个人餐补如何处理？

## 非零证据建议

| 问题 | Grade 3 核心证据 | Grade 2 实质相关证据 |
|---|---|---|
| BC01-Q021 | [I2](evidence-inventory.md#i2) | 无 |
| BC01-Q022 | [I7](evidence-inventory.md#i7) | 无 |
| BC01-Q023 | [I6](evidence-inventory.md#i6) | 无 |
| BC01-Q024 | [I1](evidence-inventory.md#i1)、[I2](evidence-inventory.md#i2) | [I4](evidence-inventory.md#i4) |
| BC01-Q025 | [E5](evidence-inventory.md#e5)、[I2](evidence-inventory.md#i2) | [I1](evidence-inventory.md#i1)、[I3](evidence-inventory.md#i3)、[I9](evidence-inventory.md#i9) |
| BC01-Q026 | [E9](evidence-inventory.md#e9)、[I5](evidence-inventory.md#i5)、[I9](evidence-inventory.md#i9) | 无 |
| BC01-Q027 | [E4](evidence-inventory.md#e4)、[I4](evidence-inventory.md#i4)、[I5](evidence-inventory.md#i5) | 无 |
| BC01-Q028 | [E6](evidence-inventory.md#e6)、[X1](evidence-inventory.md#x1)、[X7](evidence-inventory.md#x7) | 无 |
| BC01-Q029 | [X2](evidence-inventory.md#x2)、[T8](evidence-inventory.md#t8) | 无 |
| BC01-Q030 | [X6](evidence-inventory.md#x6)、[T6](evidence-inventory.md#t6) | [X5](evidence-inventory.md#x5) |

Q025–Q030 是跨文档题：Grade 3 可以分别提供不同的必要子答案，不要求每个 Grade 3 块独自回答整题。Grade 2 提供实质补充证据。仅同主题或制度转引不自动计正相关。
Q030 的 X6 要求招待餐按差旅规则扣补助，T6 提供扣减数值，两块需一起理解；等级审阅不改变冻结的二值相关映射 grade≥2。

## 八处建议修订（待审）

| 问题 / 块 | 原建议 → 新建议 | 理由 |
|---|---|---|
| BC01-Q021 / [E5](evidence-inventory.md#e5) | 1 → 0 | 仅转引安全制度，未说明家庭网络是否必须 VPN。 |
| BC01-Q021 / [I1](evidence-inventory.md#i1) | 2 → 0 | 说明 VPN/远程系统使用 MFA，不足以推出家庭网络必须连接 VPN；问题没有询问 MFA。 |
| BC01-Q021 / [I9](evidence-inventory.md#i9) | 1 → 0 | 明确酒店网络须 VPN，但没有定义家庭网络；不能把酒店条件自动移植到家庭。 |
| BC01-Q022 / [E9](evidence-inventory.md#e9) | 2 → 0 | 一般可疑邮件报告及保留线索要求，不回答邮件自带电话是否能独立核实身份。 |
| BC01-Q023 / [I9](evidence-inventory.md#i9) | 1 → 0 | 远程个人存储限制及离职介质交接，不提供现场离线交付的介质申请和使用程序。 |
| BC01-Q026 / [I1](evidence-inventory.md#i1) | 2 → 0 | 一般禁止共享凭据，没有工作成果、设备、账号停用或退出人员权限撤销的交接流程；交接专属规则见 E9/I9/I5。 |
| BC01-Q027 / [E7](evidence-inventory.md#e7) | 1 → 0 | 体检报告不能作为活动附件，不回答病假材料提交、HR 分类或内部访问控制。 |
| BC01-Q028 / [T1](evidence-inventory.md#t1) | 2 → 0 | 只界定培训费用适用制度，不提供课程/预算审批人或提交期限。 |

同一证据在不同问题中可以有不同等级：Q008 询问 MFA 系统范围，I2 有实质部分答案；Q021 只问家庭网络是否必须 VPN，I1 的 MFA 规则不能给出家庭接入条件。不得根据另一题的等级自动复制。

## 全快照矩阵：38 × 10 = 380 项

| 块 / 全文 | 主题 | Q021 | Q022 | Q023 | Q024 | Q025 | Q026 | Q027 | Q028 | Q029 | Q030 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 3 | 0 | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 2 | 0 | 0 | 3 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 | 0 | 3 | 3 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 2 | 3 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 0 |

## 确认方式

核对后可批准“Q021–Q030，R2-B04-0.1 全部 380 项等级，包括八处调整”，并列出例外；也可仅确认具体项。
完整 coverage 必须在实际检查每题全部 38 块后单独确认无遗漏正证据；等级批准不自动包含 coverage、family/split、去重或 promotion。
机器可读及逐项理由：[round2-batch-04.json](round2-batch-04.json)。
