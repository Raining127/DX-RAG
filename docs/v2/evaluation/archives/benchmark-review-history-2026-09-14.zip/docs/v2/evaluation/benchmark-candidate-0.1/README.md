**后续正式发布（2026-09-14）：** [novatech-retrieval-benchmark-1.0.0](../novatech-retrieval-benchmark-1.0.0/README.md) 已按真实 Human 决定冻结并完成 promotion；本候选包和历史审阅记录保留各时点状态。未运行 Benchmark。

# Benchmark 候选数据与人工审阅包 0.1

**状态：DRAFT / HUMAN REVIEW REQUIRED。** 2026-09-11 根据 [SPEC §1.4](../../SPEC.md) 的本轮用户授权准备，属于 [T2003 前数据构建检查点](../../TASKS.md)，不是已经冻结的 Benchmark Dataset。T2001/T2002 保持 DONE，T2003 保持 TODO。

本包包含 **40 道候选题：32 Answerable（四类各 8）+8 Unanswerable**，绑定现有 `novatech-pilot-0.1` / `t2001-novatech-pilot-01` 的 4 份原创制度、38 个实际入库 chunks。每题提供完整 38 行建议矩阵，共 **1,520 项 LLM 建议等级**；全部 Human grade 为空，全部 coverage/review 为 PENDING。没有运行 Retrieval、指标或模型，没有重新入库。

## 从这里开始审阅

**当前 Human 审阅进度（2026-09-11）：** 第一轮 40/40 完成：32 道可回答、8 道不可回答；Q001/Q003/Q007/Q015/Q027/Q031/Q032 采用改写。第二轮全部 1,520 项等级已批准，修订见各批 Human 等级记录；全部 40 题完整 coverage 已批准；family/split、最终去重、语料范围/规模差额和最终 promotion 尚未批准。最终问法、类别及决定来源以 [人工决定表](human-decisions.md) 为准。`candidates.json` 及派生批次保留原始 0.1 建议，生成时的 PENDING 状态不覆盖后续 Human ledger；改写题须以批准后的问法准备第二轮证据。

先看 [划分诊断与覆盖缺口](split-review.md)，再按批次审题。建议先审第一批，不需要一次确认全部 40 题。

**当前审阅入口（2026-09-14）：** 问法、等级及完整 coverage 均已完成，见 [含 coverage 的人工标注 0.2](reviewed-annotations-0.2.json)及 [覆盖决定](coverage-review.md)。已完成 [核心事实分组与 Dev/Test 草案](../fact-split-draft-0.1/README.md)：20 组、最大 8 题，建议两侧各 16A+4U；7 个正证据块及 2 条补充规则仍跨侧共享。**核心事实、20 个分组及 Dev/Test 已批准，共享证据及非盲测局限已接受**，见 [人工批准记录](../fact-split-draft-0.1/human-approval.md)；当前 40 题内的 [语义去重审阅](../semantic-dedup-review-0.1/human-decisions.md)已完成（20/20 组全部保留）；语料选择及质量目标差额已获 [SC01/SC02 批准](../size-corpus-review-0.1/human-decisions.md)：四份原文/冻结 38 块，题集仅当前 40 题、不并入六道 Pilot 题；正式冻结/promotion 仍未批准。[原保守分组检查](family-readiness-review.md)（9 组、最大 25 题）保留供比较。旧 0.1 及原始审阅包保留批准前状态。

| 批次 | 题号 | 内容 |
|---|---|---|
| [第一批](review-batch-01.md) | Q001–Q010 | 工作安排、假期福利、付款凭证、交通、MFA、远程资格和更新 |
| [第二批](review-batch-02.md) | Q011–Q020 | 信息保护、事件处理、报销、差旅与费用干扰 |
| [第三批](review-batch-03.md) | Q021–Q030 | 网络/身份/介质安全及跨文档业务流程 |
| [第四批](review-batch-04.md) | Q031–Q040 | 混合行程、超限审批及 8 道不可回答题 |

每题的证据链接都通向 [完整冻结正文](evidence-inventory.md)。短别名 E/X/I/T 分别代表 employee/expense/IT/travel 文件，数字为实际 chunk_index，**不是页码**。JSON 同时保留真正的 chunk_id、file_id、文件名、索引和文本 SHA-256。

[人工决定表](human-decisions.md) 是本包待填的 Human review ledger。可以在对话中逐题或批量给出决定，由 Codex 记录真实决定来源；无需手改大型 JSON。批量确认必须明确题号、包版本/快照和确认维度，不能将“继续”“看过了”解释为全部批准。

推荐审阅顺序：

1. 决定保留、改写或删除问题，并确认类别、可回答性。答案提纲帮助核对信息需求，不是另一份生成评估 Ground Truth。
2. 逐题对照全部 38 块，确认/修改建议等级。尤其检查 Grade 1 与 2 的边界，以及含有干扰数值但同时提供排除规则的完整 chunk。
3. 实际完成全快照检查后，明确是否确认没有遗漏正证据。当前 LLM screening 不能替你作出这项确认。
4. 审阅 evidence-family 和 Dev/Test；最后再决定语料复用、规模缺口与正式版本批准。当前 split 有明显缺口，不建议直接冻结。

问题或快照改变后，旧问题的 screening/coverage 不自动有效，需要重新检查。为便于审题，本次提前提供的是 **preliminary screening suggestions**，不是宣称已完成契约中 Human Query Review → Human Coverage → Human Final Approval 的流程。

## 当前最重要的缺口

- 契约目标为 40 Answerable +8 Unanswerable；本包少 8 道 Answerable，每类少 2。已有候选仍含共享核心证据，尤其 Q025 接近 Pilot-CQ-006，应优先决定是否删去/替换，而不是为达到题数继续堆改写。
- 保守的共享实质证据合并产生一个 30 题大组。拟议 Dev 为 **27 A +4 U**，Test 为 **5 A +4 U**；Test 没有可回答的 Paraphrase/Multi-chunk，不能支持均衡的类别比较。该划分是诊断用草案，不是建议批准的最终 split。
- 同一 chunk 的不同事实被保守合并，可能过度分组；Human 可以细化核心事实，但应保留可核验理由。若仍缺独立 Test 内容，应扩充语料并建立新快照；不要更改正确等级来拆组。
- 八道不可回答题均有 Grade 1 邻近政策，所问具体值不在快照。Human 批准后按既有 Runner 的 `unanswerable_weak_only` 单列，排除主指标；这类题没有覆盖所有不可回答场景。
- 现有 Pilot 六题的人工批准只属于原题与原版本，本包不继承批准。Pilot 相关题暂放 Dev；所有候选都由本次助手看过，Test 只指未来 Candidate/config 决策的拟议隔离，不宣称对作者或审阅者盲测。

## 文件与版本责任

| 文件 | 作用 |
|---|---|
| [candidates.json](candidates.json) | Canonical 候选快照：问法、建议等级、完整证据身份、原始 Human 空字段、family/split 和 provenance；不是 Runner 输入格式 |
| [human-decisions.md](human-decisions.md) | 初始 PENDING 的人工决定记录表；Human 决定必须记录版本、日期和来源；原始建议不覆盖 |
| [evidence-inventory.md](evidence-inventory.md) | 38 块逐字正文与 UUID/hash 证据索引 |
| review-batch-01～04.md | 从 JSON 渲染的审阅视图，每题 38 行，没有预填 Human 等级 |
| [split-review.md](split-review.md) | 家族成员、拟议分配、数量/类别缺口和泄漏局限 |
| [render_review.py](render_review.py) | Python 标准库生成派生 Markdown；不改 Human ledger，`--check` 只校验一致性 |
| [verify_packet.py](verify_packet.py) | 本候选版本的结构、身份、hash、覆盖与分组核验；不连接模型/索引 |
| [verification.md](verification.md) | 本次执行证据与边界 |

本候选 0.1 保留为建议来源。后续修改问法/建议应创建新的候选版本或明确记录修订；批准后的正式 schema-1 数据是后续独立产物，必须引用真实 Human ledger。不得把 `suggested_grade` 直接改名为 `human_grade`，或只改 `purpose` 来绕过审阅。

来源为 [原创语料说明](../pilot-corpus/README.md) 和 [历史入库快照](../pilot-snapshot-01/snapshot.json)。当前只验证磁盘上的文本证据与原源文件 hash；没有验证实时 Chroma 向量、模型文件是否仍匹配或恢复能力。最终语料覆盖及 Benchmark 复用待 Human 批准。数据来源是项目虚构政策，不是现实企业员工查询样本。

## 可重复检查

在仓库根目录执行：

```powershell
python docs/v2/evaluation/benchmark-candidate-0.1/verify_packet.py
python docs/v2/evaluation/benchmark-candidate-0.1/render_review.py --check
```

这里的 PASS 仅表示候选材料结构一致，不表示 Human 已批准或 T2003 ready。正式 readiness 还需实际人工决定、最终版本、可用模型/索引与 T2003 执行授权。

**正式冻结审阅入口（2026-09-14）：** 已整理 [1.0.0-rc1 冻结审阅包](../freeze-review-1.0.0-rc1/README.md)，含 40 题、1,520 项等级、来源副本、manifest 和核验结果。内容核验通过，最终冻结与 promotion 仍 PENDING；本包不运行 Benchmark。
