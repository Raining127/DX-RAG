# 第二轮批次 5：Q031–Q040 证据等级与完整覆盖

版本：`R2-B05-0.1`；绑定 `novatech-pilot-0.1` / `t2001-novatech-pilot-01`（38 chunks）。
问法及可回答性来自 [Human ledger](human-decisions.md)，含 Q031/Q032 改写。所有等级仍为建议，Human grade=null，coverage_reviewed=false。

## 已批准的问题

- **BC01-Q031**（可回答）：同一趟上海行程先培训后拜访客户，均无住宿超限特别批准，两段住宿各适用多少报销上限、预订时怎样区分用途；同一天两种活动都有，餐费能按两套规则各领一次吗？
- **BC01-Q032**（可回答）：境内普通商务出差申请已经批了，但展会酒店都超住宿限额，预计总预算也要增加，订房前应补哪些批准和证明？
- **BC01-Q033**（不可回答）：按公司规定，我这次获批用私家车出差，每公里具体报销多少元？
- **BC01-Q034**（不可回答）：我要让商家给公司开票，公司发票抬头的完整名称和纳税人识别号分别是什么？
- **BC01-Q035**（不可回答）：我的报销已通过财务审核，公司承诺最迟几个工作日一定到账？
- **BC01-Q036**（不可回答）：这次去新加坡见客户，公司已经批下来的专项预算里，每晚酒店上限是多少新加坡元？
- **BC01-Q037**（不可回答）：我今年获批的带薪年假额度具体是多少天？
- **BC01-Q038**（不可回答）：我签的这份劳动合同里，试用期具体约定了几个月？
- **BC01-Q039**（不可回答）：公司今年年度体检套餐给每位员工安排的预算具体是多少元？
- **BC01-Q040**（不可回答）：我要装公司 VPN，公司批准使用的客户端品牌和官方下载地址是什么？

## 非零证据建议

| 问题 | Grade 3 | Grade 2 | Grade 1 |
|---|---|---|---|
| BC01-Q031 | [X7](evidence-inventory.md#x7)、[T1](evidence-inventory.md#t1)、[T4](evidence-inventory.md#t4) | [E6](evidence-inventory.md#e6)、[X8](evidence-inventory.md#x8)、[T6](evidence-inventory.md#t6) | 无 |
| BC01-Q032 | [T2](evidence-inventory.md#t2)、[T5](evidence-inventory.md#t5) | [E8](evidence-inventory.md#e8)、[X8](evidence-inventory.md#x8) | 无 |
| BC01-Q033 | 无 | 无 | [T3](evidence-inventory.md#t3) |
| BC01-Q034 | 无 | 无 | [X2](evidence-inventory.md#x2) |
| BC01-Q035 | 无 | 无 | [X3](evidence-inventory.md#x3) |
| BC01-Q036 | 无 | 无 | [T8](evidence-inventory.md#t8) |
| BC01-Q037 | 无 | 无 | [E4](evidence-inventory.md#e4) |
| BC01-Q038 | 无 | 无 | [E3](evidence-inventory.md#e3) |
| BC01-Q039 | 无 | 无 | [E7](evidence-inventory.md#e7) |
| BC01-Q040 | 无 | 无 | [I2](evidence-inventory.md#i2) |

## 两处新建议修订

| 问题 / 块 | 原建议 → 新建议 | 理由 |
|---|---|---|
| BC01-Q032 / [T4](evidence-inventory.md#t4) | 1 → 0 | 本题已知酒店超限，问订房前补哪些批准和证明；正常住宿金额及用途规则不回答补审批流程。 |
| BC01-Q040 / [I3](evidence-inventory.md#i3) | 1 → 0 | 一般设备和软件保护要求，不给公司 VPN 品牌、官方下载地址或该客户端获取渠道。 |

## 不可回答题的 Grade 1 边界

本批 Q033–Q040 各保留一个邻近政策块建议 1。它们直接谈到所问对象的制度或查询依据，却没有所需具体值，因此不能给 2/3。不能仅因题目不可回答就必须保留 1，也不能因此自动将所有块判 0。
例如 Q035/X3 提供付款批次却没有到账保证；Q037/E4 指向实际个人年假额度所在的员工系统；Q038/E3 指向个人劳动合同。这些是同一信息需求的有限背景。Q039/E7 对体检预算只有间接背景，1/0 边界尤其需要审阅。
Human 可以逐项将这些 1 调为 0；没有新增正证据时，仍不改变第一轮不可回答性。旧批次对其他 query/chunk 的批准不能替代本批判断。
若这些弱相关等级获批且其余 readiness 满足，现有 Runner 会将其作为 unanswerable_weak_only 单列，不纳入主要 Answerable 指标。本轮未运行 Runner，也不证明生成层能正确拒答。

## 全快照矩阵：38 × 10 = 380 项

| 块 / 全文 | 主题 | Q031 | Q032 | Q033 | Q034 | Q035 | Q036 | Q037 | Q038 | Q039 | Q040 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 2 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |

## 确认方式

核对后可批准“Q031–Q040，R2-B05-0.1 全部 380 项等级，包括两处调整”，并列其他例外；也可只确认部分项。
完整 coverage 仍需单独确认每题全快照无遗漏正证据。最后一批等级完成也不自动批准 coverage、family/split、去重、规模缺口或 promotion。
机器可读及逐项理由：[round2-batch-05.json](round2-batch-05.json)。
