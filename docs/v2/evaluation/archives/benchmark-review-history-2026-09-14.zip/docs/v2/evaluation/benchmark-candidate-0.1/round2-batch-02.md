# 第二轮批次 2：Q005–Q010 证据等级与完整覆盖

版本：`R2-B02-0.1`；绑定 `novatech-pilot-0.1` / `t2001-novatech-pilot-01`（38 chunks）。
全部等级为待审建议；Human grade=null，coverage_reviewed=false。采用 [Human ledger](human-decisions.md) 的批准问法，含 Q007 改写。
Codex 按完整冻结正文复核，提出下面四项建议修订；不将 Q002/E6 的 Human 决定外推为本批批准。原候选包和原建议均保留。

## 已批准的问题

- **BC01-Q005**：财务审核通过的员工垫付款通常哪天集中支付，返还到哪个账户？
- **BC01-Q006**：境内消费的电子发票要交什么文件？只有付款截图可以吗，发票信息错了怎么办？
- **BC01-Q007**：境内普通商务出差一般选什么高铁席位或飞机舱位？没有普通席位而必须升级时谁批准？
- **BC01-Q008**：哪些公司系统必须启用 MFA？更换手机后怎样恢复认证访问？
- **BC01-Q009**：我还在试用期，想固定每周在家干两天，可以按常规远程办公安排申请吗？
- **BC01-Q010**：IT 催我装关键更新，但这两天要在客户现场工作，赶不及怎么办？

## 本次建议修订（全部待 Human 确认）

| 问题 / 块 | 原建议 → 新建议 | 理由 |
|---|---|---|
| BC01-Q005 / [X4](evidence-inventory.md#x4) | 1 → 0 | 区分支付方式但不提供付款日或收款账户，不回答本题所需事实。 |
| BC01-Q006 / [X1](evidence-inventory.md#x1) | 1 → 0 | 只要求有效凭证，没有电子文件形式、截图替代或错误更正规则。 |
| BC01-Q008 / [I2](evidence-inventory.md#i2) | 1 → 2 | 明确公司 VPN 接入必须使用 MFA，实质回答系统范围中的一个部分；未给完整系统清单或换机恢复流程。 |
| BC01-Q009 / [I9](evidence-inventory.md#i9) | 1 → 0 | 转引远程申请并说明设备限制，没有回答试用期员工的常规申请资格。 |

## 全快照矩阵：38 × 6 = 228 项

所有行都链接完整原文。Grade 3 为核心答案，Grade 2 为实质部分答案；仅同主题但不提供所问信息的块建议 0。

| 块 / 全文 | 主题 | Q005 | Q006 | Q007 | Q008 | Q009 | Q010 |
|---|---|---:|---:|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 | 3 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 3 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 3 | 0 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 3 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 2 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 | 0 | 3 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 3 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 | 0 | 0 |

## 确认范围

可以批准“Q005–Q010，R2-B02-0.1 全部 228 项等级（含四处新建议）”，并列出例外。也可以只批准指定 query/chunk。
等级通过不等于 coverage；只有实际核对每题完整 38 块后才单独确认无遗漏正证据。Family/split 和最终 promotion 均留待后续。
机器可读版本：[round2-batch-02.json](round2-batch-02.json)。原始建议与变更理由均保留；所有 Human 字段待填。
