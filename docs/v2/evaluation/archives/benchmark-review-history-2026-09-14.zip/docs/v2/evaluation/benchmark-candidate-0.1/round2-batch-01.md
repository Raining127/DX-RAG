# 第二轮首批：Q001–Q004 证据等级与完整覆盖

版本：`R2-B01-0.1`；2026-09-11；绑定 `novatech-pilot-0.1` / `t2001-novatech-pilot-01`（38 chunks）。
第一轮最终问法取自 [Human ledger](human-decisions.md)；本包是新的待审建议，不覆盖原 Candidate 0.1。
Codex 本次重新阅读全部冻结正文，针对 Q001/Q003 改写复核；未提议调整原等级。LLM screening 不等于 Human coverage。
所有等级和 coverage 仍 PENDING；没有运行检索、指标或更新正式 Benchmark。

## 已批准的问题

- **BC01-Q001**：不涉及客户现场排班时，正常工作日允许几点到岗？午休多长，下班时间怎样确定？
- **BC01-Q002**：新员工入职首周由谁说明岗位目标、安排带教和培训？试用期间多久反馈一次？
- **BC01-Q003**：非紧急情况下，计划连续请假三天和四天，通常各需提前多少个工作日申请？
- **BC01-Q004**：年度体检由谁统一预约？自己加做检查前需要确认什么？

## 优先审阅的非零等级

| 问题 | 证据正文 | 建议 | 理由 |
|---|---|---:|---|
| BC01-Q001 | [E2](evidence-inventory.md#e2) | 3 | 直接列出到岗范围、午休和下班顺延规则。 |
| BC01-Q002 | [E3](evidence-inventory.md#e3) | 3 | 同块完整列出首周安排和每月反馈。 |
| BC01-Q002 | [E6](evidence-inventory.md#e6) | 1 | 说明新员工有入职培训，但不含本题所问角色与反馈频率。 |
| BC01-Q003 | [E4](evidence-inventory.md#e4) | 3 | 明确三天以内与超过三天的两档提前量。 |
| BC01-Q004 | [E7](evidence-inventory.md#e7) | 3 | 直接规定体检预约责任和额外项目确认。 |

**最需要判断的边界：Q002 → E6 建议 Grade 1。** E6 说公司安排入职培训，但没有给出谁安排安全/制度培训、指定带教或试用反馈频率；因此只是弱背景，不是实质答案。若认为这种背景不应计相关，可改为 0 并记录理由。
Q001 → E5 仍建议 0：约定协作时段可联系没有回答到岗范围、午休或下班顺延。Q003 → E2/T2 建议 0：漏考勤/差旅申请中的“三个工作日”不是计划请假的提前量。
E1 的通用 HR 服务渠道对这四题均建议 0，不因出现 HR 就视为回答了具体安排。

## 全快照矩阵：38 行 × 4 题

所有数字均是显式 LLM 建议；Human 等级全为空。请结合每行链接的完整正文检查，不把未发现遗漏当成自动 coverage 批准。

| 块 / 全文 | 主题 | Q001 | Q002 | Q003 | Q004 |
|---|---|---:|---:|---:|---:|
| [E0](evidence-inventory.md#e0) | NovaTech（诺瓦科技）员工手册 | 0 | 0 | 0 | 0 |
| [E1](evidence-inventory.md#e1) | 适用范围与服务渠道 | 0 | 0 | 0 | 0 |
| [E2](evidence-inventory.md#e2) | 工作时间与考勤 | 3 | 0 | 0 | 0 |
| [E3](evidence-inventory.md#e3) | 试用期与岗位支持 | 0 | 3 | 0 | 0 |
| [E4](evidence-inventory.md#e4) | 年假与病假 | 0 | 0 | 3 | 0 |
| [E5](evidence-inventory.md#e5) | 远程办公 | 0 | 0 | 0 | 0 |
| [E6](evidence-inventory.md#e6) | 培训与职业发展 | 0 | 1 | 0 | 0 |
| [E7](evidence-inventory.md#e7) | 员工福利 | 0 | 0 | 0 | 3 |
| [E8](evidence-inventory.md#e8) | 出差与费用责任 | 0 | 0 | 0 | 0 |
| [E9](evidence-inventory.md#e9) | 信息保护与离职交接 | 0 | 0 | 0 | 0 |
| [X0](evidence-inventory.md#x0) | NovaTech（诺瓦科技）费用报销制度 | 0 | 0 | 0 | 0 |
| [X1](evidence-inventory.md#x1) | 费用原则与提交期限 | 0 | 0 | 0 | 0 |
| [X2](evidence-inventory.md#x2) | 发票与证明材料 | 0 | 0 | 0 | 0 |
| [X3](evidence-inventory.md#x3) | 审批与结算 | 0 | 0 | 0 | 0 |
| [X4](evidence-inventory.md#x4) | 员工垫付与公司卡 | 0 | 0 | 0 | 0 |
| [X5](evidence-inventory.md#x5) | 普通差旅费用 | 0 | 0 | 0 | 0 |
| [X6](evidence-inventory.md#x6) | 业务招待 | 0 | 0 | 0 | 0 |
| [X7](evidence-inventory.md#x7) | 获批外部培训费用 | 0 | 0 | 0 | 0 |
| [X8](evidence-inventory.md#x8) | 超限、变更与不予报销事项 | 0 | 0 | 0 | 0 |
| [I0](evidence-inventory.md#i0) | NovaTech（诺瓦科技）信息安全制度 | 0 | 0 | 0 | 0 |
| [I1](evidence-inventory.md#i1) | 账号、密码与 MFA | 0 | 0 | 0 | 0 |
| [I2](evidence-inventory.md#i2) | 网络接入与 VPN | 0 | 0 | 0 | 0 |
| [I3](evidence-inventory.md#i3) | 公司设备与软件 | 0 | 0 | 0 | 0 |
| [I4](evidence-inventory.md#i4) | 数据分类与处理 | 0 | 0 | 0 | 0 |
| [I5](evidence-inventory.md#i5) | 文件共享与外部协作 | 0 | 0 | 0 | 0 |
| [I6](evidence-inventory.md#i6) | 可移动存储与打印 | 0 | 0 | 0 | 0 |
| [I7](evidence-inventory.md#i7) | 钓鱼邮件与可疑链接 | 0 | 0 | 0 | 0 |
| [I8](evidence-inventory.md#i8) | 账号异常与安全事件 | 0 | 0 | 0 | 0 |
| [I9](evidence-inventory.md#i9) | 远程办公、出差与离职 | 0 | 0 | 0 | 0 |
| [T0](evidence-inventory.md#t0) | NovaTech（诺瓦科技）差旅管理制度 | 0 | 0 | 0 | 0 |
| [T1](evidence-inventory.md#t1) | 适用范围与出行目的 | 0 | 0 | 0 | 0 |
| [T2](evidence-inventory.md#t2) | 差旅申请与审批 | 0 | 0 | 0 | 0 |
| [T3](evidence-inventory.md#t3) | 城际交通 | 0 | 0 | 0 | 0 |
| [T4](evidence-inventory.md#t4) | 普通商务出差住宿 | 0 | 0 | 0 | 0 |
| [T5](evidence-inventory.md#t5) | 住宿超限与特别批准 | 0 | 0 | 0 | 0 |
| [T6](evidence-inventory.md#t6) | 餐费补助与市内交通 | 0 | 0 | 0 | 0 |
| [T7](evidence-inventory.md#t7) | 取消、改签与行程延长 | 0 | 0 | 0 | 0 |
| [T8](evidence-inventory.md#t8) | 境外出差与返回交接 | 0 | 0 | 0 | 0 |

## 如何留下决定

可只批准已核对的具体 query/chunk 等级；其余维度继续 PENDING。若批准整张矩阵，请明确“Q001–Q004，R2-B01-0.1 的全部 152 项等级”，并列例外。
全快照覆盖是单独决定：只有实际检查了每题对应的全部 38 块后，才确认“已完成完整快照检查，无遗漏正证据”。可以在同一条回复中分别确认等级和覆盖，也可以只确认等级。
这些决定仍不批准 family/split、最终去重、语料规模或 dataset promotion。Human 决定落在 human-decisions.md，原 JSON 建议不覆盖。

## 本次材料核验

源 Candidate hash：`ffff809843a84bfe6412321a6597d0f15301724db0c0866e32683695a4a08428`。
机器可读审阅快照：[round2-batch-01.json](round2-batch-01.json)。
四题均逐字匹配 ledger 的批准问法；152 个判断逐项绑定原冻结 chunk_id/file_id/文件名/index；原始文本 hash 和快照文件 hash 已对照。所有 Human grade 为 null，coverage_reviewed=false。
仅证明材料身份和结构一致，不证明人工批准、语义完整性或真实索引可用。
